# WordPress MySQL database migration
#
# Generated: Friday 3. March 2023 17:29 UTC
# Hostname: localhost
# Database: `local`
# URL: //acfheadless.wpengine.local
# Path: /Users/jeff.everhart/Local Sites/headless-wp-demo/app/public
# Tables: wp_acm_post_to_post, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, action_monitor, attachment, nav_menu_item, page, post, spacelaunch, wp_global_styles
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_acm_post_to_post`
#

DROP TABLE IF EXISTS `wp_acm_post_to_post`;


#
# Table structure of table `wp_acm_post_to_post`
#

CREATE TABLE `wp_acm_post_to_post` (
  `id1` bigint(20) unsigned NOT NULL,
  `id2` bigint(20) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `id1_id2_name` (`id1`,`id2`,`name`),
  KEY `id2_name` (`id2`,`name`),
  KEY `id2_name_order` (`id2`,`name`,`order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_acm_post_to_post`
#

#
# End of data contents of table `wp_acm_post_to_post`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=391 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://acfheadless.wpengine.local', 'yes'),
(2, 'home', 'https://acfheadless.wpengine.local', 'yes'),
(3, 'blogname', 'Headless WP Demo', 'yes'),
(4, 'blogdescription', 'Your frontend framework powered by WP', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'jeff.everhart@wpengine.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:94:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:10:"graphql/?$";s:22:"index.php?graphql=true";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:19:"faustwp/faustwp.php";i:2;s:41:"wp-graphql-acf-develop/wp-graphql-acf.php";i:3;s:25:"wp-graphql/wp-graphql.php";i:4;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'genesis-block-theme', 'yes'),
(41, 'stylesheet', 'genesis-block-theme', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '38', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1679257862', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:33:"read_private_action_monitor_posts";b:1;s:32:"edit_others_action_monitor_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:33:"read_private_action_monitor_posts";b:1;s:32:"edit_others_action_monitor_posts";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:12:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:33:"read_private_action_monitor_posts";b:1;s:32:"edit_others_action_monitor_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:7:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:33:"read_private_action_monitor_posts";b:1;s:32:"edit_others_action_monitor_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '1', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(104, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:10:{i:1677864664;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1677868990;a:1:{s:49:"WPEngineSecurityAuditor_Scans_fingerprint_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1677875464;a:5:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1677875534;a:1:{s:39:"WPEngineSecurityAuditor_Scans_scheduler";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1677900594;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1677943794;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1677943795;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1678307464;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1678397749;a:1:{s:29:"wp-graphql_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_wpe_powered_by_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'theme_mods_twentytwentytwo', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1663706661;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(121, 'current_theme', 'Genesis Block Theme', 'yes'),
(122, 'theme_switched', '', 'yes'),
(123, 'theme_mods_genesis-block-theme', 'a:2:{s:18:"nav_menu_locations";a:2:{s:7:"primary";i:3;s:6:"footer";i:0;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(124, 'genesis_pro_subscription_key', '4cd46405-187e-4c85-9f4f-cd1a1462cdea', 'yes'),
(125, 'wpe_template', 'Genesis Blocks Blank Pro', 'yes'),
(126, 'recovery_keys', 'a:0:{}', 'yes'),
(127, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'yes'),
(129, 'wpe-health-check-site-status-result', '{"good":15,"recommended":5,"critical":0}', 'yes'),
(130, 'genesis_blocks_has_content_to_migrate', '0', 'yes'),
(131, 'can_compress_scripts', '0', 'no'),
(133, 'finished_updating_comment_type', '1', 'yes'),
(134, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(135, 'recently_activated', 'a:4:{s:34:"advanced-custom-fields-pro/acf.php";i:1677356835;s:47:"atlas-content-modeler/atlas-content-modeler.php";i:1677356775;s:49:"wp-graphql-smart-cache/wp-graphql-smart-cache.php";i:1677356745;s:23:"wp-gatsby/wp-gatsby.php";i:1677356736;}', 'yes'),
(138, 'wp-graphql_allow_tracking', 'yes', 'yes'),
(141, 'atlas_content_modeler_post_types', 'a:1:{s:11:"spacelaunch";a:11:{s:12:"show_in_rest";b:1;s:15:"show_in_graphql";b:1;s:10:"rest_route";s:24:"/wpe/atlas/content-model";s:8:"singular";s:12:"Space Launch";s:6:"plural";s:14:"Space Launches";s:4:"slug";s:11:"spacelaunch";s:14:"api_visibility";s:6:"public";s:10:"model_icon";s:20:"dashicons-admin-site";s:11:"description";s:0:"";s:6:"fields";a:4:{i:1663864169747;a:17:{s:12:"show_in_rest";b:1;s:15:"show_in_graphql";b:1;s:10:"rest_route";s:30:"/wpe/atlas/content-model-field";s:4:"type";s:4:"text";s:2:"id";s:13:"1663864169747";s:8:"position";s:1:"0";s:4:"name";s:7:"Mission";s:4:"slug";s:7:"mission";s:12:"isRepeatable";b:0;s:7:"isTitle";b:1;s:9:"inputType";s:6:"single";s:8:"required";b:1;s:11:"description";s:0:"";s:8:"minChars";s:0:"";s:8:"maxChars";s:0:"";s:13:"minRepeatable";s:0:"";s:13:"maxRepeatable";s:0:"";}i:1663864181070;a:16:{s:12:"show_in_rest";b:1;s:15:"show_in_graphql";b:1;s:10:"rest_route";s:30:"/wpe/atlas/content-model-field";s:4:"type";s:4:"text";s:2:"id";s:13:"1663864181070";s:8:"position";s:5:"10000";s:4:"name";s:9:"Call Sign";s:4:"slug";s:8:"callSign";s:12:"isRepeatable";b:0;s:9:"inputType";s:6:"single";s:8:"required";b:1;s:11:"description";s:0:"";s:8:"minChars";s:0:"";s:8:"maxChars";s:0:"";s:13:"minRepeatable";s:0:"";s:13:"maxRepeatable";s:0:"";}i:1663864200436;a:16:{s:12:"show_in_rest";b:1;s:15:"show_in_graphql";b:1;s:10:"rest_route";s:30:"/wpe/atlas/content-model-field";s:4:"type";s:4:"text";s:2:"id";s:13:"1663864200436";s:8:"position";s:5:"20000";s:4:"name";s:5:"Pilot";s:4:"slug";s:5:"pilot";s:12:"isRepeatable";b:0;s:9:"inputType";s:6:"single";s:8:"required";b:0;s:11:"description";s:0:"";s:8:"minChars";s:0:"";s:8:"maxChars";s:0:"";s:13:"minRepeatable";s:0:"";s:13:"maxRepeatable";s:0:"";}i:1663864209063;a:15:{s:12:"show_in_rest";b:1;s:15:"show_in_graphql";b:1;s:10:"rest_route";s:30:"/wpe/atlas/content-model-field";s:4:"type";s:4:"date";s:2:"id";s:13:"1663864209063";s:8:"position";s:5:"30000";s:4:"name";s:11:"Flight Date";s:4:"slug";s:10:"flightDate";s:8:"required";b:1;s:11:"description";s:0:"";s:8:"minChars";s:0:"";s:8:"maxChars";s:0:"";s:13:"minRepeatable";s:0:"";s:13:"maxRepeatable";s:0:"";s:16:"isRepeatableDate";b:0;}}s:10:"with_front";i:0;}}', 'yes'),
(142, 'atlas_content_modeler_current_version', '0.23.0', 'yes'),
(143, 'wp_acm_post_to_post_schema_version', '0.1.0', 'no'),
(147, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(150, 'atlas_content_modeler_taxonomies', 'a:1:{s:13:"flightvehicle";a:8:{s:5:"types";a:1:{i:0;s:11:"spacelaunch";}s:12:"show_in_rest";b:1;s:15:"show_in_graphql";b:1;s:12:"hierarchical";b:0;s:14:"api_visibility";s:6:"public";s:8:"singular";s:14:"flight vehicle";s:6:"plural";s:14:"flightvehicles";s:4:"slug";s:13:"flightvehicle";}}', 'yes'),
(160, 'category_children', 'a:0:{}', 'yes'),
(161, 'WPLANG', '', 'yes'),
(162, 'new_admin_email', 'jeff.everhart@wpengine.com', 'yes'),
(166, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(167, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(193, 'wpgatsby_settings', 'a:1:{s:18:"preview_jwt_secret";s:50:"wPZq9lP/OnqL88b/rJQdK1FyxAFdy36oHe+s7iF+Cfp3TUlz+f";}', 'yes'),
(194, '_gatsby_tracked_post_types', 'a:4:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";i:3;s:11:"spacelaunch";}', 'yes'),
(195, '_gatsby_tracked_taxonomies', 'a:4:{i:0;s:8:"category";i:1;s:8:"post_tag";i:2;s:11:"post_format";i:3;s:13:"flightvehicle";}', 'yes'),
(196, 'acf_version', '6.0.7', 'yes'),
(208, 'recovery_mode_email_last_sent', '1677356759', 'yes'),
(210, 'wp_graphql_version', '1.13.6', 'yes'),
(211, 'graphql_general_settings', 'a:15:{s:16:"graphql_endpoint";s:7:"graphql";s:36:"restrict_endpoint_to_logged_in_users";s:3:"off";s:21:"batch_queries_enabled";s:2:"on";s:11:"batch_limit";s:2:"10";s:19:"query_depth_enabled";s:3:"off";s:15:"query_depth_max";s:2:"10";s:16:"graphiql_enabled";s:2:"on";s:31:"show_graphiql_link_in_admin_bar";s:2:"on";s:25:"delete_data_on_deactivate";s:2:"on";s:18:"debug_mode_enabled";s:3:"off";s:15:"tracing_enabled";s:3:"off";s:17:"tracing_user_role";s:13:"administrator";s:18:"query_logs_enabled";s:3:"off";s:19:"query_log_user_role";s:13:"administrator";s:28:"public_introspection_enabled";s:3:"off";}', 'yes'),
(226, 'graphql_persisted_queries_section', 'a:2:{s:10:"grant_mode";s:6:"public";s:14:"editor_display";s:2:"on";}', 'yes'),
(227, 'graphql_cache_section', '', 'yes'),
(228, 'wp-graphql_tracking_last_send', '1677208396', 'yes'),
(237, 'wp_migrate_addon_schema', '1', 'yes'),
(249, 'wpmdb_wpe_remote_cookie', 'fb19b3f95f41b73241cfac8764f2b910f770a73e8eddcdca7bc1899f7133feed', 'no'),
(253, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1677864582;}', 'no'),
(264, 'blog_public', '0', 'yes'),
(265, 'upload_path', '', 'yes'),
(266, 'upload_url_path', '', 'yes'),
(320, 'faustwp_settings', 'a:6:{s:12:"frontend_uri";s:21:"http://localhost:3000";s:10:"secret_key";s:36:"ad85da6c-d580-4173-ad4b-af2402c6589d";s:14:"menu_locations";s:15:"Primary, Footer";s:13:"disable_theme";s:1:"1";s:15:"enable_rewrites";s:1:"1";s:16:"enable_redirects";s:1:"1";}', 'yes'),
(321, 'faustwp_current_version', '0.8.1', 'yes'),
(345, 'nonce_key', '46n(Ou|7ZsNN(.$+X:%fny&Q@1&|K;js4Vhg1?z;uQOQa1f? YZ@. Q2Vd0Kg?9r', 'no'),
(346, 'nonce_salt', 'vN%at(}@%LU-~g_QbTjAW>Tzo3FCJ~&0WL]9/.*q#0&Uq)IiT]H#sj;v$_{&O}<T', 'no'),
(353, 'secure_auth_key', '[c(K(lU6muME$~|:s4Z4k%B0z6c[oAEh* YdvsJ&ic.8XtP(,vE6lEt;$w;`;pd{', 'no'),
(354, 'secure_auth_salt', '4wbTFp;|VAjr%-[Y`ZJP[<XNgjT[!AC]>=qs-&U#PT1nr}bG:H(X^v`i/cT8Ns^-', 'no'),
(355, 'logged_in_key', '+6vwAM<(_{&9$?L:4-h:+=+kqlb,epa[}M_VAy1T.~$=#=(X%3u_dhh4l{$^T6fP', 'no'),
(356, 'logged_in_salt', '=}P$0Ld3-nry6D%j >+AS~,YR|}xc())+p$e+$(!Uo/;xatcNEOS*3ZV7emX}*vH', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=843 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7, 5, '_edit_lock', '1677693633:1'),
(9, 7, '_edit_lock', '1677693134:1'),
(12, 9, '_edit_lock', '1677693061:1'),
(14, 10, '_edit_lock', '1677692877:1'),
(16, 12, '_wp_attached_file', '2022/09/krisztian-tabori-ZQf4jzkpz1k-unsplash.jpg'),
(17, 12, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:640;s:6:"height";i:427;s:4:"file";s:49:"2022/09/krisztian-tabori-ZQf4jzkpz1k-unsplash.jpg";s:8:"filesize";i:69080;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:49:"krisztian-tabori-ZQf4jzkpz1k-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15677;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"krisztian-tabori-ZQf4jzkpz1k-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8255;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:49:"krisztian-tabori-ZQf4jzkpz1k-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15677;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(19, 13, '_wp_attached_file', '2022/09/charlesdeluvio-la6DtkODelg-unsplash.jpg'),
(20, 13, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:640;s:6:"height";i:427;s:4:"file";s:47:"2022/09/charlesdeluvio-la6DtkODelg-unsplash.jpg";s:8:"filesize";i:109132;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:47:"charlesdeluvio-la6DtkODelg-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22546;}s:9:"thumbnail";a:5:{s:4:"file";s:47:"charlesdeluvio-la6DtkODelg-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9801;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:47:"charlesdeluvio-la6DtkODelg-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22546;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(22, 14, '_edit_last', '1'),
(23, 14, 'mission', 'MR-3'),
(24, 14, '_wp_old_slug', '14'),
(25, 14, 'callSign', 'Freedom 7'),
(26, 14, 'pilot', 'Shepard'),
(27, 14, 'flightDate', '1961-05-05'),
(28, 14, '_edit_lock', '1663864126:1'),
(29, 15, '_edit_last', '1'),
(30, 15, 'mission', 'MR-4'),
(31, 15, '_wp_old_slug', '15'),
(32, 15, 'callSign', 'Liberty Bell 7'),
(33, 15, 'pilot', 'Grissom'),
(34, 15, 'flightDate', '1961-07-21'),
(35, 15, '_edit_lock', '1663864155:1'),
(36, 16, '_edit_last', '1'),
(37, 16, 'mission', 'MA-6'),
(38, 16, '_wp_old_slug', '16'),
(39, 16, 'callSign', 'Friendship 7'),
(40, 16, 'pilot', 'Glenn'),
(41, 16, 'flightDate', '1962-02-20'),
(42, 16, '_edit_lock', '1663864188:1'),
(43, 17, '_edit_last', '1'),
(44, 17, 'mission', 'MA-7'),
(45, 17, '_wp_old_slug', '17'),
(46, 17, 'callSign', 'Aurora 7'),
(47, 17, 'pilot', 'Carpenter'),
(48, 17, 'flightDate', '1962-05-24'),
(49, 17, '_edit_lock', '1663864222:1'),
(50, 18, '_edit_last', '1'),
(51, 18, 'mission', 'MA-8'),
(52, 18, '_wp_old_slug', '18'),
(53, 18, 'callSign', 'Sigma 7'),
(54, 18, 'pilot', 'Schirra'),
(55, 18, 'flightDate', '1962-10-03'),
(56, 18, '_edit_lock', '1667499327:1'),
(58, 10, '_thumbnail_id', '32'),
(60, 9, '_thumbnail_id', '13'),
(61, 20, '_wp_attached_file', '2022/10/adi-goldstein-QfN0l0MZCyc-unsplash.jpg'),
(62, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:7952;s:6:"height";i:5304;s:4:"file";s:46:"2022/10/adi-goldstein-QfN0l0MZCyc-unsplash.jpg";s:8:"filesize";i:7994545;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:46:"adi-goldstein-QfN0l0MZCyc-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16455;}s:5:"large";a:5:{s:4:"file";s:47:"adi-goldstein-QfN0l0MZCyc-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:99282;}s:9:"thumbnail";a:5:{s:4:"file";s:46:"adi-goldstein-QfN0l0MZCyc-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7983;}s:12:"medium_large";a:5:{s:4:"file";s:46:"adi-goldstein-QfN0l0MZCyc-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:64281;}s:9:"1536x1536";a:5:{s:4:"file";s:48:"adi-goldstein-QfN0l0MZCyc-unsplash-1536x1025.jpg";s:5:"width";i:1536;s:6:"height";i:1025;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:184941;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:47:"adi-goldstein-QfN0l0MZCyc-unsplash-1200x800.jpg";s:5:"width";i:1200;s:6:"height";i:800;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:126181;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:47:"adi-goldstein-QfN0l0MZCyc-unsplash-1400x934.jpg";s:5:"width";i:1400;s:6:"height";i:934;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:159809;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:46:"adi-goldstein-QfN0l0MZCyc-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16455;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(64, 7, '_thumbnail_id', '20'),
(65, 21, '_wp_attached_file', '2022/10/bruno-guerrero-vlLpPqOYg-8-unsplash-scaled.jpg'),
(66, 21, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:54:"2022/10/bruno-guerrero-vlLpPqOYg-8-unsplash-scaled.jpg";s:8:"filesize";i:439577;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:47:"bruno-guerrero-vlLpPqOYg-8-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11038;}s:5:"large";a:5:{s:4:"file";s:48:"bruno-guerrero-vlLpPqOYg-8-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:82102;}s:9:"thumbnail";a:5:{s:4:"file";s:47:"bruno-guerrero-vlLpPqOYg-8-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5615;}s:12:"medium_large";a:5:{s:4:"file";s:47:"bruno-guerrero-vlLpPqOYg-8-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:50295;}s:9:"1536x1536";a:5:{s:4:"file";s:49:"bruno-guerrero-vlLpPqOYg-8-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:167153;}s:9:"2048x2048";a:5:{s:4:"file";s:49:"bruno-guerrero-vlLpPqOYg-8-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:284121;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:48:"bruno-guerrero-vlLpPqOYg-8-unsplash-1200x800.jpg";s:5:"width";i:1200;s:6:"height";i:800;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:107947;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:48:"bruno-guerrero-vlLpPqOYg-8-unsplash-1400x933.jpg";s:5:"width";i:1400;s:6:"height";i:933;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:142094;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:47:"bruno-guerrero-vlLpPqOYg-8-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11038;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:39:"bruno-guerrero-vlLpPqOYg-8-unsplash.jpg";}'),
(68, 5, '_thumbnail_id', '21'),
(69, 22, '_edit_lock', '1677692798:1'),
(71, 23, '_edit_lock', '1677692564:1'),
(73, 24, '_edit_lock', '1677692239:1'),
(75, 25, '_wp_attached_file', '2022/10/kim-ick-JdfNXZAuk98-unsplash-scaled.jpg'),
(76, 25, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1710;s:4:"file";s:47:"2022/10/kim-ick-JdfNXZAuk98-unsplash-scaled.jpg";s:8:"filesize";i:363375;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:40:"kim-ick-JdfNXZAuk98-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10792;}s:5:"large";a:5:{s:4:"file";s:41:"kim-ick-JdfNXZAuk98-unsplash-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:63773;}s:9:"thumbnail";a:5:{s:4:"file";s:40:"kim-ick-JdfNXZAuk98-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5585;}s:12:"medium_large";a:5:{s:4:"file";s:40:"kim-ick-JdfNXZAuk98-unsplash-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41003;}s:9:"1536x1536";a:5:{s:4:"file";s:42:"kim-ick-JdfNXZAuk98-unsplash-1536x1026.jpg";s:5:"width";i:1536;s:6:"height";i:1026;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:127538;}s:9:"2048x2048";a:5:{s:4:"file";s:42:"kim-ick-JdfNXZAuk98-unsplash-2048x1368.jpg";s:5:"width";i:2048;s:6:"height";i:1368;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:223932;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:41:"kim-ick-JdfNXZAuk98-unsplash-1200x802.jpg";s:5:"width";i:1200;s:6:"height";i:802;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:82970;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:41:"kim-ick-JdfNXZAuk98-unsplash-1400x935.jpg";s:5:"width";i:1400;s:6:"height";i:935;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:107921;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:40:"kim-ick-JdfNXZAuk98-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10792;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:32:"kim-ick-JdfNXZAuk98-unsplash.jpg";}'),
(78, 24, '_thumbnail_id', '25'),
(79, 26, '_edit_lock', '1677692208:1'),
(80, 27, '_wp_attached_file', '2022/10/chen-yij-lOTEL9Vfz7k-unsplash-scaled.jpg'),
(81, 27, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:48:"2022/10/chen-yij-lOTEL9Vfz7k-unsplash-scaled.jpg";s:8:"filesize";i:258790;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:41:"chen-yij-lOTEL9Vfz7k-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11771;}s:5:"large";a:5:{s:4:"file";s:42:"chen-yij-lOTEL9Vfz7k-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:66869;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"chen-yij-lOTEL9Vfz7k-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6528;}s:12:"medium_large";a:5:{s:4:"file";s:41:"chen-yij-lOTEL9Vfz7k-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44046;}s:9:"1536x1536";a:5:{s:4:"file";s:43:"chen-yij-lOTEL9Vfz7k-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:119610;}s:9:"2048x2048";a:5:{s:4:"file";s:43:"chen-yij-lOTEL9Vfz7k-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:184219;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:42:"chen-yij-lOTEL9Vfz7k-unsplash-1200x800.jpg";s:5:"width";i:1200;s:6:"height";i:800;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:83702;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:42:"chen-yij-lOTEL9Vfz7k-unsplash-1400x933.jpg";s:5:"width";i:1400;s:6:"height";i:933;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:105368;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:41:"chen-yij-lOTEL9Vfz7k-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11771;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:33:"chen-yij-lOTEL9Vfz7k-unsplash.jpg";}'),
(84, 26, '_thumbnail_id', '27'),
(90, 29, '_wp_attached_file', '2022/10/mike-kenneally-TD4DBagg2wE-unsplash-scaled.jpg'),
(91, 29, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1952;s:4:"file";s:54:"2022/10/mike-kenneally-TD4DBagg2wE-unsplash-scaled.jpg";s:8:"filesize";i:845801;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:47:"mike-kenneally-TD4DBagg2wE-unsplash-300x229.jpg";s:5:"width";i:300;s:6:"height";i:229;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:24055;}s:5:"large";a:5:{s:4:"file";s:48:"mike-kenneally-TD4DBagg2wE-unsplash-1024x781.jpg";s:5:"width";i:1024;s:6:"height";i:781;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:183086;}s:9:"thumbnail";a:5:{s:4:"file";s:47:"mike-kenneally-TD4DBagg2wE-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9123;}s:12:"medium_large";a:5:{s:4:"file";s:47:"mike-kenneally-TD4DBagg2wE-unsplash-768x586.jpg";s:5:"width";i:768;s:6:"height";i:586;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:113280;}s:9:"1536x1536";a:5:{s:4:"file";s:49:"mike-kenneally-TD4DBagg2wE-unsplash-1536x1171.jpg";s:5:"width";i:1536;s:6:"height";i:1171;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:360283;}s:9:"2048x2048";a:5:{s:4:"file";s:49:"mike-kenneally-TD4DBagg2wE-unsplash-2048x1562.jpg";s:5:"width";i:2048;s:6:"height";i:1562;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:583706;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:48:"mike-kenneally-TD4DBagg2wE-unsplash-1200x915.jpg";s:5:"width";i:1200;s:6:"height";i:915;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:238829;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:49:"mike-kenneally-TD4DBagg2wE-unsplash-1400x1068.jpg";s:5:"width";i:1400;s:6:"height";i:1068;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:308560;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:47:"mike-kenneally-TD4DBagg2wE-unsplash-300x229.jpg";s:5:"width";i:300;s:6:"height";i:229;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:24055;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:39:"mike-kenneally-TD4DBagg2wE-unsplash.jpg";}'),
(93, 30, '_wp_attached_file', '2022/10/jose-luis-espindola-1L0o_htiew8-unsplash-scaled.jpg'),
(94, 30, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1696;s:4:"file";s:59:"2022/10/jose-luis-espindola-1L0o_htiew8-unsplash-scaled.jpg";s:8:"filesize";i:408266;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:52:"jose-luis-espindola-1L0o_htiew8-unsplash-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15603;}s:5:"large";a:5:{s:4:"file";s:53:"jose-luis-espindola-1L0o_htiew8-unsplash-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:96829;}s:9:"thumbnail";a:5:{s:4:"file";s:52:"jose-luis-espindola-1L0o_htiew8-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7861;}s:12:"medium_large";a:5:{s:4:"file";s:52:"jose-luis-espindola-1L0o_htiew8-unsplash-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:63289;}s:9:"1536x1536";a:5:{s:4:"file";s:54:"jose-luis-espindola-1L0o_htiew8-unsplash-1536x1018.jpg";s:5:"width";i:1536;s:6:"height";i:1018;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:179224;}s:9:"2048x2048";a:5:{s:4:"file";s:54:"jose-luis-espindola-1L0o_htiew8-unsplash-2048x1357.jpg";s:5:"width";i:2048;s:6:"height";i:1357;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:283110;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:53:"jose-luis-espindola-1L0o_htiew8-unsplash-1200x795.jpg";s:5:"width";i:1200;s:6:"height";i:795;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:122933;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:53:"jose-luis-espindola-1L0o_htiew8-unsplash-1400x927.jpg";s:5:"width";i:1400;s:6:"height";i:927;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:154951;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:52:"jose-luis-espindola-1L0o_htiew8-unsplash-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15603;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:44:"jose-luis-espindola-1L0o_htiew8-unsplash.jpg";}'),
(96, 23, '_thumbnail_id', '30'),
(99, 32, '_wp_attached_file', '2022/10/lucas-lenzi-zeT_i6av9rU-unsplash-scaled.jpg'),
(100, 32, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:51:"2022/10/lucas-lenzi-zeT_i6av9rU-unsplash-scaled.jpg";s:8:"filesize";i:252035;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:44:"lucas-lenzi-zeT_i6av9rU-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9694;}s:5:"large";a:5:{s:4:"file";s:45:"lucas-lenzi-zeT_i6av9rU-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:56212;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"lucas-lenzi-zeT_i6av9rU-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5376;}s:12:"medium_large";a:5:{s:4:"file";s:44:"lucas-lenzi-zeT_i6av9rU-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:36550;}s:9:"1536x1536";a:5:{s:4:"file";s:46:"lucas-lenzi-zeT_i6av9rU-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:105697;}s:9:"2048x2048";a:5:{s:4:"file";s:46:"lucas-lenzi-zeT_i6av9rU-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:168938;}s:34:"genesis-block-theme-featured-image";a:5:{s:4:"file";s:45:"lucas-lenzi-zeT_i6av9rU-unsplash-1200x800.jpg";s:5:"width";i:1200;s:6:"height";i:800;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:71402;}s:39:"genesis-block-theme-featured-image-wide";a:5:{s:4:"file";s:45:"lucas-lenzi-zeT_i6av9rU-unsplash-1400x933.jpg";s:5:"width";i:1400;s:6:"height";i:933;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:91083;}s:24:"genesis-block-theme-logo";a:5:{s:4:"file";s:44:"lucas-lenzi-zeT_i6av9rU-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9694;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:36:"lucas-lenzi-zeT_i6av9rU-unsplash.jpg";}'),
(129, 38, '_edit_lock', '1667928381:1'),
(130, 39, '_edit_lock', '1667928851:1'),
(131, 40, '_edit_lock', '1667928350:1'),
(132, 40, '_edit_last', '1'),
(133, 40, '_wp_page_template', 'default'),
(134, 39, '_edit_last', '1'),
(135, 39, '_wp_page_template', 'default'),
(136, 26, '_edit_last', '1'),
(138, 24, '_edit_last', '1'),
(140, 23, '_edit_last', '1'),
(142, 22, '_edit_last', '1'),
(144, 10, '_edit_last', '1'),
(147, 7, '_edit_last', '1'),
(149, 5, '_edit_last', '1'),
(157, 41, '_menu_item_type', 'post_type'),
(158, 41, '_menu_item_menu_item_parent', '0'),
(159, 41, '_menu_item_object_id', '38'),
(160, 41, '_menu_item_object', 'page'),
(161, 41, '_menu_item_target', ''),
(162, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(163, 41, '_menu_item_xfn', ''),
(164, 41, '_menu_item_url', ''),
(166, 42, '_menu_item_type', 'post_type'),
(167, 42, '_menu_item_menu_item_parent', '0'),
(168, 42, '_menu_item_object_id', '40'),
(169, 42, '_menu_item_object', 'page'),
(170, 42, '_menu_item_target', ''),
(171, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(172, 42, '_menu_item_xfn', ''),
(173, 42, '_menu_item_url', ''),
(175, 43, '_menu_item_type', 'post_type'),
(176, 43, '_menu_item_menu_item_parent', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(177, 43, '_menu_item_object_id', '39'),
(178, 43, '_menu_item_object', 'page'),
(179, 43, '_menu_item_target', ''),
(180, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(181, 43, '_menu_item_xfn', ''),
(182, 43, '_menu_item_url', ''),
(187, 22, '_thumbnail_id', '29'),
(188, 41, '_wp_old_date', '2022-11-07'),
(189, 42, '_wp_old_date', '2022-11-07'),
(190, 43, '_wp_old_date', '2022-11-07'),
(457, 161, 'referenced_node_status', 'update_non_node_root_field'),
(458, 161, 'referenced_node_single_name', 'updateNonNodeRootField'),
(459, 161, 'referenced_node_plural_name', 'updateNonNodeRootField'),
(460, 162, '_edit_lock', '1677356680:1'),
(461, 162, '_edit_last', '1'),
(470, 26, 'blog_posts_0_title', 'How to Make Chicharrones Recipe'),
(471, 26, '_blog_posts_0_title', 'field_6385212b12628'),
(472, 26, 'blog_posts_0_url', 'https://www.seriouseats.com/the-nasty-bits-how-to-make-chicharrones-recipe'),
(473, 26, '_blog_posts_0_url', 'field_6385213d12629'),
(474, 26, 'blog_posts_1_title', 'CHICHARRONES (CHICHARRON DE CERDO PORK RIND)'),
(475, 26, '_blog_posts_1_title', 'field_6385212b12628'),
(476, 26, 'blog_posts_1_url', 'https://www.dominicancooking.com/chicharrones-recipe-dominican-chicharron-cerdo'),
(477, 26, '_blog_posts_1_url', 'field_6385213d12629'),
(478, 26, 'blog_posts', '2'),
(479, 26, '_blog_posts', 'field_638520ba12627'),
(480, 26, 'videos', '2'),
(481, 26, '_videos', 'field_638521521262a'),
(483, 26, 'videos_0_title', 'How to make Authentic Mexican Chicharrones / Fried pork belly'),
(484, 26, '_videos_0_title', 'field_6385217f1262b'),
(485, 26, 'videos_0_url', 'https://www.youtube.com/watch?v=jzCpDKU3v5Q'),
(486, 26, '_videos_0_url', 'field_638521e71262c'),
(487, 26, 'videos_1_title', 'EASY Homemade Chicharrones | Crispy Pork Belly | Simply Mamá Cooks'),
(488, 26, '_videos_1_title', 'field_6385217f1262b'),
(489, 26, 'videos_1_url', 'https://www.youtube.com/watch?v=isLJfDf-s-g'),
(490, 26, '_videos_1_url', 'field_638521e71262c'),
(554, 24, 'blog_posts_0_title', 'How to cook fluffy Quinoa'),
(555, 24, '_blog_posts_0_title', 'field_6385212b12628'),
(556, 24, 'blog_posts_0_url', 'https://www.loveandlemons.com/quinoa/'),
(557, 24, '_blog_posts_0_url', 'field_6385213d12629'),
(558, 24, 'blog_posts_1_title', 'Quinoa Wiki'),
(559, 24, '_blog_posts_1_title', 'field_6385212b12628'),
(560, 24, 'blog_posts_1_url', 'https://en.wikipedia.org/wiki/Quinoa'),
(561, 24, '_blog_posts_1_url', 'field_6385213d12629'),
(562, 24, 'blog_posts', '2'),
(563, 24, '_blog_posts', 'field_638520ba12627'),
(564, 24, 'videos', '2'),
(565, 24, '_videos', 'field_638521521262a'),
(568, 24, 'videos_0_title', 'Healthy Quinoa'),
(569, 24, '_videos_0_title', 'field_6385217f1262b'),
(570, 24, 'videos_0_url', 'https://www.youtube.com/watch?v=6ylVPXDF4cI'),
(571, 24, '_videos_0_url', 'field_638521e71262c'),
(572, 24, 'videos_1_title', 'Best Quinoa'),
(573, 24, '_videos_1_title', 'field_6385217f1262b'),
(574, 24, 'videos_1_url', 'https://www.youtube.com/watch?v=lOhfj7btW_s'),
(575, 24, '_videos_1_url', 'field_638521e71262c'),
(581, 23, 'blog_posts_0_title', 'Outdoor Fanny Packs'),
(582, 23, '_blog_posts_0_title', 'field_6385212b12628'),
(583, 23, 'blog_posts_0_url', 'https://www.outdoorgearlab.com/topics/camping-and-hiking/best-fanny-pack'),
(584, 23, '_blog_posts_0_url', 'field_6385213d12629'),
(585, 23, 'blog_posts_1_title', '80\'s epic Mixtape'),
(586, 23, '_blog_posts_1_title', 'field_6385212b12628'),
(587, 23, 'blog_posts_1_url', 'https://urbanmatter.com/80s-mixtape-best-songs-from-the-iconic-decade/'),
(588, 23, '_blog_posts_1_url', 'field_6385213d12629'),
(589, 23, 'blog_posts', '2'),
(590, 23, '_blog_posts', 'field_638520ba12627'),
(591, 23, 'videos_0_title', 'Fanny Packs are Rad'),
(592, 23, '_videos_0_title', 'field_6385217f1262b'),
(593, 23, 'videos_0_url', 'https://youtu.be/dQ-hLFNVtbA'),
(594, 23, '_videos_0_url', 'field_638521e71262c'),
(595, 23, 'videos_1_title', 'Sweet Mixtape!'),
(596, 23, '_videos_1_title', 'field_6385217f1262b'),
(597, 23, 'videos_1_url', 'https://www.youtube.com/watch?v=rwYrEEka1mc'),
(598, 23, '_videos_1_url', 'field_638521e71262c'),
(599, 23, 'videos', '2'),
(600, 23, '_videos', 'field_638521521262a'),
(606, 22, 'blog_posts_0_title', 'Coffee Wiki'),
(607, 22, '_blog_posts_0_title', 'field_6385212b12628'),
(608, 22, 'blog_posts_0_url', 'https://en.wikipedia.org/wiki/Coffee'),
(609, 22, '_blog_posts_0_url', 'field_6385213d12629'),
(610, 22, 'blog_posts_1_title', 'What the heck is Coffee??'),
(611, 22, '_blog_posts_1_title', 'field_6385212b12628'),
(612, 22, 'blog_posts_1_url', 'https://www.ncausa.org/About-Coffee/What-is-Coffee'),
(613, 22, '_blog_posts_1_url', 'field_6385213d12629'),
(614, 22, 'blog_posts', '2'),
(615, 22, '_blog_posts', 'field_638520ba12627'),
(616, 22, 'videos_0_title', 'Coffee Love'),
(617, 22, '_videos_0_title', 'field_6385217f1262b'),
(618, 22, 'videos_0_url', 'https://www.youtube.com/watch?v=mKlJUTPNiXM'),
(619, 22, '_videos_0_url', 'field_638521e71262c'),
(620, 22, 'videos_1_title', 'Coffee History Lesson'),
(621, 22, '_videos_1_title', 'field_6385217f1262b'),
(622, 22, 'videos_1_url', 'https://www.youtube.com/watch?v=mKlJUTPNiXM'),
(623, 22, '_videos_1_url', 'field_638521e71262c'),
(624, 22, 'videos', '2'),
(625, 22, '_videos', 'field_638521521262a'),
(631, 10, 'blog_posts_0_title', 'Tribal Tattoos'),
(632, 10, '_blog_posts_0_title', 'field_6385212b12628'),
(633, 10, 'blog_posts_0_url', 'https://tattmag.com/tribal-tattoo/'),
(634, 10, '_blog_posts_0_url', 'field_6385213d12629'),
(635, 10, 'blog_posts_1_title', 'Tattoo meanings') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(636, 10, '_blog_posts_1_title', 'field_6385212b12628'),
(637, 10, 'blog_posts_1_url', 'https://tatring.com/tattoo-ideas-meanings/Tribal-Tattoo-Designs-Ideas-for-tribal-tattoos-for-Men-and-Women'),
(638, 10, '_blog_posts_1_url', 'field_6385213d12629'),
(639, 10, 'blog_posts', '2'),
(640, 10, '_blog_posts', 'field_638520ba12627'),
(641, 10, 'videos_0_title', 'LA Ink'),
(642, 10, '_videos_0_title', 'field_6385217f1262b'),
(643, 10, 'videos_0_url', 'https://www.youtube.com/watch?v=PNsh_BVJFiQ'),
(644, 10, '_videos_0_url', 'field_638521e71262c'),
(645, 10, 'videos_1_title', 'Ink Masters'),
(646, 10, '_videos_1_title', 'field_6385217f1262b'),
(647, 10, 'videos_1_url', 'https://www.youtube.com/watch?v=5d7T94wd-90'),
(648, 10, '_videos_1_url', 'field_638521e71262c'),
(649, 10, 'videos', '2'),
(650, 10, '_videos', 'field_638521521262a'),
(655, 9, '_edit_last', '1'),
(657, 9, 'blog_posts_0_title', 'Kale Origins'),
(658, 9, '_blog_posts_0_title', 'field_6385212b12628'),
(659, 9, 'blog_posts_0_url', 'https://www.wholefoodsmarket.com/tips-and-ideas/archive/kale-history-varieties-and-tips-kristen-beddard'),
(660, 9, '_blog_posts_0_url', 'field_6385213d12629'),
(661, 9, 'blog_posts_1_title', 'Kale Makers'),
(662, 9, '_blog_posts_1_title', 'field_6385212b12628'),
(663, 9, 'blog_posts_1_url', 'https://www.nytimes.com/2013/10/20/magazine/who-made-that-kale.html'),
(664, 9, '_blog_posts_1_url', 'field_6385213d12629'),
(665, 9, 'blog_posts', '2'),
(666, 9, '_blog_posts', 'field_638520ba12627'),
(667, 9, 'videos_0_title', 'History of Kale'),
(668, 9, '_videos_0_title', 'field_6385217f1262b'),
(669, 9, 'videos_0_url', 'https://www.youtube.com/watch?v=W0rjjmmLNAk'),
(670, 9, '_videos_0_url', 'field_638521e71262c'),
(671, 9, 'videos_1_title', 'Grow Perfect Kale'),
(672, 9, '_videos_1_title', 'field_6385217f1262b'),
(673, 9, 'videos_1_url', 'https://www.youtube.com/watch?v=vIFRTNJiaAc'),
(674, 9, '_videos_1_url', 'field_638521e71262c'),
(675, 9, 'videos', '2'),
(676, 9, '_videos', 'field_638521521262a'),
(683, 7, 'blog_posts_0_title', 'How does it work?'),
(684, 7, '_blog_posts_0_title', 'field_6385212b12628'),
(685, 7, 'blog_posts_0_url', 'https://electronics.howstuffworks.com/vcr1.htm'),
(686, 7, '_blog_posts_0_url', 'field_6385213d12629'),
(687, 7, 'blog_posts_1_title', 'VHS tapes worth a goldmine'),
(688, 7, '_blog_posts_1_title', 'field_6385212b12628'),
(689, 7, 'blog_posts_1_url', 'https://www.familyminded.com/s/valuable-vhs-tapes-worth-something-465e6b8ca0944a20'),
(690, 7, '_blog_posts_1_url', 'field_6385213d12629'),
(695, 7, 'blog_posts', '2'),
(696, 7, '_blog_posts', 'field_638520ba12627'),
(697, 7, 'videos_0_title', 'VHS Tapes- Good or Bad?'),
(698, 7, '_videos_0_title', 'field_6385217f1262b'),
(699, 7, 'videos_0_url', 'https://www.youtube.com/watch?v=P00QS3lXJeI'),
(700, 7, '_videos_0_url', 'field_638521e71262c'),
(701, 7, 'videos_1_title', 'Convert your VHS tapes!'),
(702, 7, '_videos_1_title', 'field_6385217f1262b'),
(703, 7, 'videos_1_url', 'https://www.youtube.com/watch?v=X5ckSpuyuY8'),
(704, 7, '_videos_1_url', 'field_638521e71262c'),
(705, 7, 'videos', '2'),
(706, 7, '_videos', 'field_638521521262a'),
(712, 5, 'blog_posts_0_title', 'Classic Casettes'),
(713, 5, '_blog_posts_0_title', 'field_6385212b12628'),
(714, 5, 'blog_posts_0_url', 'https://www.thecassetteplace.com/'),
(715, 5, '_blog_posts_0_url', 'field_6385213d12629'),
(716, 5, 'blog_posts_1_title', '8 Tracks and Casettes'),
(717, 5, '_blog_posts_1_title', 'field_6385212b12628'),
(718, 5, 'blog_posts_1_url', 'https://www.npr.org/sections/therecord/2011/02/17/133692586/8-track-tapes-belong-in-a-museum#:~:text=%22The%20cassette%20surpassed%20the%208,the%20Sony%20Walkman%20were%20introduced.'),
(719, 5, '_blog_posts_1_url', 'field_6385213d12629'),
(720, 5, 'blog_posts', '2'),
(721, 5, '_blog_posts', 'field_638520ba12627'),
(722, 5, 'videos', '2'),
(723, 5, '_videos', 'field_638521521262a'),
(725, 5, 'videos_0_title', 'Casettes killed the 8-track'),
(726, 5, '_videos_0_title', 'field_6385217f1262b'),
(727, 5, 'videos_0_url', 'https://www.youtube.com/watch?v=f-vnhUpq0Lo'),
(728, 5, '_videos_0_url', 'field_638521e71262c'),
(729, 5, 'videos_1_title', 'Explore Casettes'),
(730, 5, '_videos_1_title', 'field_6385217f1262b'),
(731, 5, 'videos_1_url', 'https://www.youtube.com/watch?v=H5m6zs1UIVg'),
(732, 5, '_videos_1_url', 'field_638521e71262c'),
(741, 162, '_wp_trash_meta_status', 'publish'),
(742, 162, '_wp_trash_meta_time', '1677356828'),
(743, 162, '_wp_desired_post_slug', 'group_638520b93d809'),
(744, 163, '_wp_trash_meta_status', 'publish'),
(745, 163, '_wp_trash_meta_time', '1677356828'),
(746, 163, '_wp_desired_post_slug', 'field_638520ba12627'),
(747, 166, '_wp_trash_meta_status', 'publish'),
(748, 166, '_wp_trash_meta_time', '1677356828'),
(749, 166, '_wp_desired_post_slug', 'field_638521521262a'),
(750, 196, '_edit_lock', '1677631480:1'),
(751, 196, '_edit_last', '1'),
(754, 200, '_edit_last', '1'),
(755, 200, '_edit_lock', '1677688281:1'),
(756, 204, '_edit_last', '1'),
(757, 204, '_edit_lock', '1677684139:1'),
(758, 204, '_wp_trash_meta_status', 'publish'),
(759, 204, '_wp_trash_meta_time', '1677691868'),
(760, 204, '_wp_desired_post_slug', 'group_63ff6c9002a6b'),
(761, 205, '_wp_trash_meta_status', 'publish'),
(762, 205, '_wp_trash_meta_time', '1677691868'),
(763, 205, '_wp_desired_post_slug', 'field_63ff6c91404d4'),
(764, 206, '_wp_trash_meta_status', 'publish'),
(765, 206, '_wp_trash_meta_time', '1677691868'),
(766, 206, '_wp_desired_post_slug', 'field_63ff6cc3404d5') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(774, 22, 'recipe_name', 'How to Make Pour-Over Coffee'),
(775, 22, '_recipe_name', 'field_63fa6f84a5ffb'),
(776, 22, 'recipe_link', 'https://minimalistbaker.com/how-to-make-pour-over-coffee/'),
(777, 22, '_recipe_link', 'field_63fa6f583bdb5'),
(778, 22, 'track_title', 'One More Cup of Coffee'),
(779, 22, '_track_title', 'field_63ff6941b60fd'),
(780, 22, 'artist', 'Bob Dylan'),
(781, 22, '_artist', 'field_63ff6969dcdae'),
(782, 22, 'album', 'Bob Dylan – The Rolling Thunder Revue: The 1975 Live Recordings'),
(783, 22, '_album', 'field_63ff6975dcdaf'),
(786, 26, 'recipe_name', 'How to Make Colombian-Style Chicharrones'),
(787, 26, '_recipe_name', 'field_63fa6f84a5ffb'),
(788, 26, 'recipe_link', 'https://www.seriouseats.com/the-nasty-bits-how-to-make-chicharrones-recipe'),
(789, 26, '_recipe_link', 'field_63fa6f583bdb5'),
(792, 24, 'recipe_name', 'Seriously Good Quinoa Salad'),
(793, 24, '_recipe_name', 'field_63fa6f84a5ffb'),
(794, 24, 'recipe_link', 'https://www.inspiredtaste.net/38096/quinoa-salad-recipe/'),
(795, 24, '_recipe_link', 'field_63fa6f583bdb5'),
(798, 23, 'recipe_name', 'Dandelion Salad'),
(799, 23, '_recipe_name', 'field_63fa6f84a5ffb'),
(800, 23, 'recipe_link', 'https://nourishedkitchen.com/dandelion-salad/'),
(801, 23, '_recipe_link', 'field_63fa6f583bdb5'),
(802, 23, 'track_title', 'Mix Tape'),
(803, 23, '_track_title', 'field_63ff6941b60fd'),
(804, 23, 'artist', 'Brand New '),
(805, 23, '_artist', 'field_63ff6969dcdae'),
(806, 23, 'album', 'Your Favorite Weapon'),
(807, 23, '_album', 'field_63ff6975dcdaf'),
(812, 10, 'recipe_name', 'Best Ground Beef Taco Recipes'),
(813, 10, '_recipe_name', 'field_63fa6f84a5ffb'),
(814, 10, 'recipe_link', 'https://houseofyumm.com/best-ever-taco-meat/'),
(815, 10, '_recipe_link', 'field_63fa6f583bdb5'),
(818, 9, 'recipe_name', 'Baked Kale Chips'),
(819, 9, '_recipe_name', 'field_63fa6f84a5ffb'),
(820, 9, 'recipe_link', 'https://www.allrecipes.com/recipe/176957/baked-kale-chips/'),
(821, 9, '_recipe_link', 'field_63fa6f583bdb5'),
(825, 7, 'track_title', 'Take On Me'),
(826, 7, '_track_title', 'field_63ff6941b60fd'),
(827, 7, 'artist', 'A-ha'),
(828, 7, '_artist', 'field_63ff6969dcdae'),
(829, 7, 'album', 'Hunting High and Low'),
(830, 7, '_album', 'field_63ff6975dcdaf'),
(832, 5, '_encloseme', '1'),
(833, 5, 'recipe_name', 'A foodie\'s guide to salmon'),
(834, 5, '_recipe_name', 'field_63fa6f84a5ffb'),
(835, 5, 'recipe_link', 'https://www.msc.org/what-you-can-do/eat-sustainable-seafood/foodies-guides/sustainable-salmon'),
(836, 5, '_recipe_link', 'field_63fa6f583bdb5'),
(837, 5, 'track_title', 'The Mixed Tape'),
(838, 5, '_track_title', 'field_63ff6941b60fd'),
(839, 5, 'artist', 'Jack’s Mannequin'),
(840, 5, '_artist', 'field_63ff6969dcdae'),
(841, 5, 'album', 'Everything in Transit'),
(842, 5, '_album', 'field_63ff6975dcdaf') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(5, 4, '2022-09-22 16:11:42', '2022-09-22 16:11:42', '<!-- wp:paragraph -->\n<p>I\'m baby sustainable aesthetic mixtape, meditation lumbersexual bespoke offal readymade raclette beard forage fingerstache single-origin coffee tofu listicle. Sriracha YOLO shaman letterpress banjo hella. Synth succulents bicycle rights, authentic direct trade chartreuse slow-carb messenger bag ugh 3 wolf moon franzen pabst fixie. Stumptown poutine lo-fi cliche. Copper mug mustache sartorial bodega boys tonx. Affogato gochujang gatekeep next level whatever raclette tilde cloud bread chambray mukbang salvia, lumbersexual cliche bespoke.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>VHS twee celiac hexagon, raw denim next level roof party yes plz heirloom migas meh venmo af. Raw denim wayfarers slow-carb messenger bag crucifix, mixtape pitchfork copper mug typewriter. Fit irony blog ennui, four dollar toast lomo PBR&amp;B portland af DIY lo-fi neutra vexillologist franzen. Yes plz hexagon live-edge, gentrify messenger bag ennui meditation 3 wolf moon meh lyft umami cold-pressed kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"align":"center","id":21,"width":512,"height":342,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image aligncenter size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/bruno-guerrero-vlLpPqOYg-8-unsplash-1024x683.jpg" alt="" class="wp-image-21" width="512" height="342"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@bdilla810?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Bruno Guerrero</a> on <a href="https://unsplash.com/s/photos/mixtape?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Cray hashtag bespoke poke biodiesel keytar mlkshk bitters +1 fanny pack fingerstache sriracha tonx. Brooklyn PBR&amp;B meditation, kitsch meh tacos bespoke drinking vinegar master cleanse yr deep v vaporware. Truffaut YOLO post-ironic ugh, hexagon snackwave unicorn affogato kombucha live-edge subway tile godard butcher. Chartreuse jianbing schlitz, art party ramps ascot seitan migas before they sold out whatever cornhole cray gastropub gatekeep tousled. Live-edge thundercats austin DSA pinterest iPhone, knausgaard normcore fit hexagon ennui mukbang. 8-bit biodiesel intelligentsia whatever vibecession, migas four loko enamel pin taxidermy next level shoreditch same. Iceland tattooed tumeric freegan echo park mumblecore dreamcatcher cornhole bushwick YOLO direct trade tofu.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Edison bulb farm-to-table banh mi tilde occupy kinfolk XOXO kombucha franzen yr whatever tofu fashion axe. Tacos godard hella chia Brooklyn cred leggings fit humblebrag tofu selfies crucifix mixtape. Skateboard art party pop-up everyday carry succulents praxis lomo vice williamsburg ennui salvia farm-to-table. Poke food truck big mood everyday carry. Af lyft celiac wayfarers gentrify whatever. Meh hashtag migas roof party.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Before they sold out celiac waistcoat, vibecession selvage aesthetic beard tilde listicle big mood meh. Bruh street art wolf tonx. Activated charcoal bushwick cronut, vexillologist typewriter YOLO vibecession readymade stumptown selvage authentic. Pok pok yuccie seitan humblebrag. Craft beer church-key pickled austin offal shoreditch raclette. Meh four dollar toast bespoke selfies plaid williamsburg raclette meditation live-edge sustainable slow-carb.</p>\n<!-- /wp:paragraph -->', 'Sustainable Aesthetic Mixtape', '', 'publish', 'open', 'open', '', 'sustainable-aesthetic-mixtape', '', '', '2023-03-01 17:55:15', '2023-03-01 17:55:15', '', 0, 'https://acfheadless.wpengine.local/?p=5', 0, 'post', '', 0),
(6, 4, '2022-09-22 16:11:22', '2022-09-22 16:11:22', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-genesis-block-theme', '', '', '2022-09-22 16:11:22', '2022-09-22 16:11:22', '', 0, 'https://acfheadless.wpengine.local/?p=6', 0, 'wp_global_styles', '', 0),
(7, 4, '2022-09-22 16:20:39', '2022-09-22 16:20:39', '<!-- wp:paragraph -->\n<p>I\'m baby kinfolk synth DIY, street art beard helvetica drinking vinegar tofu +1 la croix jianbing. Ascot subway tile four dollar toast ugh dreamcatcher roof party pop-up godard kinfolk food truck twee kickstarter 8-bit live-edge. Hashtag activated charcoal vexillologist, salvia kale chips pinterest try-hard ascot tattooed. JOMO leggings pickled, cornhole next level tofu vibecession lumbersexual prism mukbang master cleanse chambray ramps.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Four dollar toast meh selfies venmo. Hella snackwave artisan, lo-fi big mood street art bruh same you probably haven\'t heard of them gochujang. Microdosing banh mi pop-up, tilde vinyl tumeric sartorial. Farm-to-table tilde keytar banjo poke meh af bespoke tumblr 3 wolf moon DSA health goth franzen vibecession green juice. Tumeric polaroid typewriter Brooklyn vexillologist. Tumeric kinfolk deep v, subway tile hammock yr kitsch raw denim enamel pin paleo venmo. Swag green juice woke small batch brunch cliche hashtag raw denim disrupt offal food truck vinyl.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":20,"width":512,"height":342,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/adi-goldstein-QfN0l0MZCyc-unsplash-1024x683.jpg" alt="" class="wp-image-20" width="512" height="342"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@adigold1?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Adi Goldstein</a> on <a href="https://unsplash.com/s/photos/synth?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Slow-carb keffiyeh chambray, direct trade yuccie adaptogen mlkshk put a bird on it raclette coloring book. Poke knausgaard ennui actually yr stumptown polaroid yuccie yes plz viral bespoke post-ironic. Listicle bespoke tbh, la croix try-hard 3 wolf moon mlkshk poke vaporware slow-carb heirloom letterpress. Wolf tbh godard post-ironic, art party master cleanse gochujang. Cray twee cold-pressed yes plz ramps kogi marfa echo park gentrify mukbang wolf unicorn. Shabby chic blue bottle praxis, activated charcoal celiac polaroid tattooed air plant succulents kitsch humblebrag.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Air plant poke hammock bodega boys. Asymmetrical photo booth tattooed kickstarter, chartreuse shoreditch leggings sartorial. Before they sold out mixtape tousled umami literally. Vegan deep v microdosing keffiyeh VHS intelligentsia gentrify messenger bag yes plz bicycle rights enamel pin hella etsy.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Schlitz keytar lo-fi, mukbang yr seitan semiotics 8-bit jean shorts franzen stumptown same jianbing VHS. Keytar hammock artisan brunch pour-over kickstarter. Humblebrag umami crucifix pug fam, williamsburg asymmetrical waistcoat master cleanse wayfarers shoreditch cliche cloud bread jean shorts. Kale chips literally pok pok, bushwick beard green juice praxis mustache aesthetic succulents.</p>\n<!-- /wp:paragraph -->', 'Kinfolk Synth DIY', '', 'publish', 'open', 'open', '', 'kinfolk-synth-diy', '', '', '2023-03-01 17:52:14', '2023-03-01 17:52:14', '', 0, 'https://acfheadless.wpengine.local/?p=7', 0, 'post', '', 0),
(9, 4, '2022-09-22 16:21:40', '2022-09-22 16:21:40', '<!-- wp:paragraph -->\n<p>I\'m baby migas schlitz chartreuse, disrupt kale chips poutine viral craft beer dreamcatcher etsy gastropub. Offal drinking vinegar pok pok tattooed pop-up. Occupy synth chartreuse, stumptown wayfarers fanny pack migas intelligentsia. Sus tumblr bitters vexillologist. Synth banh mi gastropub pour-over aesthetic leggings gluten-free tilde slow-carb photo booth.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":13,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/09/charlesdeluvio-la6DtkODelg-unsplash.jpg" alt="" class="wp-image-13"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Neutra taiyaki helvetica microdosing mustache, DIY franzen cronut cardigan tousled keffiyeh austin retro yr. Tattooed narwhal ascot, beard heirloom PBR&amp;B swag 90\'s JOMO mlkshk. Gluten-free vinyl dreamcatcher put a bird on it tumblr kickstarter. Taxidermy PBR&amp;B salvia, stumptown pabst big mood ennui locavore fanny pack church-key direct trade. Forage next level you probably haven\'t heard of them craft beer. Pop-up yr dreamcatcher kale chips scenester chia pabst messenger bag echo park intelligentsia man braid kinfolk lumbersexual.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>DIY subway tile umami keffiyeh iPhone raclette offal mukbang pop-up chia post-ironic heirloom af food truck. Typewriter polaroid hexagon praxis selvage 8-bit pickled organic waistcoat. Banjo pop-up yuccie tonx, shaman 8-bit man bun hell of banh mi. Marfa narwhal jean shorts ascot 90\'s messenger bag. Thundercats tote bag offal tbh, typewriter VHS twee 90\'s. Cardigan actually bespoke YOLO.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Unicorn lumbersexual neutra, cred lo-fi sartorial deep v twee flannel yes plz shaman locavore. PBR&amp;B asymmetrical listicle, selfies helvetica tilde twee bodega boys lyft street art cliche lomo master cleanse synth. Hoodie street art letterpress wolf fixie irony. Locavore mukbang small batch meggings, health goth vibecession hexagon try-hard. 3 wolf moon tonx taiyaki portland godard lomo shaman deep v enamel pin williamsburg photo booth yes plz cliche taxidermy. Direct trade austin ennui kinfolk. Blog whatever austin, lomo deep v cornhole salvia pinterest bushwick godard subway tile banh mi hexagon 3 wolf moon.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Helvetica raclette man bun photo booth, mixtape four dollar toast pickled williamsburg blue bottle cloud bread mukbang put a bird on it yuccie shabby chic tumblr. Art party vape post-ironic, big mood franzen austin lo-fi pork belly cronut flannel pok pok bespoke gochujang hashtag butcher. Scenester tote bag drinking vinegar cliche glossier disrupt gentrify copper mug kogi pitchfork cornhole pinterest palo santo vegan. Keffiyeh live-edge cardigan hexagon man braid chicharrones twee vice ethical hashtag synth venmo. Cornhole try-hard banjo pop-up heirloom coloring book enamel pin bushwick four dollar toast next level hot chicken deep v you probably haven\'t heard of them actually live-edge.</p>\n<!-- /wp:paragraph -->', 'Disrupt Kale Chips', '', 'publish', 'open', 'open', '', 'disrupt-kale-chips', '', '', '2023-03-01 17:51:01', '2023-03-01 17:51:01', '', 0, 'https://acfheadless.wpengine.local/?p=9', 0, 'post', '', 0),
(10, 4, '2022-09-22 16:22:22', '2022-09-22 16:22:22', '<!-- wp:paragraph -->\n<p>I\'m baby pour-over food truck Brooklyn, wolf keytar marfa tofu sriracha. Tattooed four loko authentic, fam pinterest art party seitan banh mi +1 tofu shabby chic twee gatekeep. Copper mug deep v +1 hashtag edison bulb vexillologist hexagon. Hoodie bodega boys letterpress meditation distillery. Succulents green juice bruh semiotics skateboard. Vexillologist pork belly readymade, selfies photo booth craft beer blue bottle vice cronut flexitarian seitan tonx tbh.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":32,"width":512,"height":342,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/lucas-lenzi-zeT_i6av9rU-unsplash-1024x683.jpg" alt="" class="wp-image-32" width="512" height="342"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@lucaslenzi?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Lucas Lenzi</a> on <a href="https://unsplash.com/s/photos/tattoos?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Street art vaporware flexitarian ethical celiac edison bulb aesthetic jean shorts wolf bodega boys wayfarers. Williamsburg neutra sartorial mlkshk, try-hard shabby chic woke. Pug mumblecore slow-carb bicycle rights XOXO. Leggings readymade franzen meggings. Poke intelligentsia yuccie lomo quinoa.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Gentrify Tacos</h2>\n<!-- /wp:heading -->\n\n<!-- wp:image {"id":12,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/09/krisztian-tabori-ZQf4jzkpz1k-unsplash.jpg" alt="" class="wp-image-12"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Vape ugh four loko selvage, gentrify tacos air plant cloud bread. Asymmetrical try-hard lomo gluten-free literally vegan cold-pressed pitchfork locavore mustache. Actually stumptown iceland disrupt artisan street art literally enamel pin, thundercats chillwave umami meggings. Semiotics gastropub twee celiac hella, 8-bit ascot chia. Kinfolk swag adaptogen, sartorial truffaut heirloom tousled kickstarter ugh YOLO tbh franzen narwhal blue bottle pickled. Chillwave microdosing kogi master cleanse deep v kinfolk cred green juice activated charcoal af same shaman gluten-free. Schlitz pok pok williamsburg sriracha.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Af listicle stumptown vexillologist chartreuse gochujang. You probably haven\'t heard of them kale chips street art green juice lomo, crucifix tilde. Pok pok tumeric messenger bag man braid, venmo organic disrupt taxidermy live-edge yes plz shoreditch sus. Readymade helvetica master cleanse, bicycle rights williamsburg dreamcatcher 90\'s mlkshk brunch single-origin coffee actually put a bird on it. DSA gatekeep adaptogen, Brooklyn microdosing neutra skateboard polaroid lumbersexual af heirloom shaman bicycle rights la croix.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Locavore twee williamsburg, photo booth pork belly microdosing meggings. Kogi air plant green juice, cray street art raw denim ramps disrupt meggings yes plz portland YOLO brunch. Letterpress church-key banh mi keffiyeh artisan fashion axe try-hard thundercats live-edge narwhal mlkshk vaporware. Roof party VHS coloring book affogato, craft beer raw denim fam paleo. Literally hell of green juice polaroid humblebrag glossier.</p>\n<!-- /wp:paragraph -->', 'Tattoed Four Loko', '', 'publish', 'open', 'open', '', 'tattoed-four-loko', '', '', '2023-03-01 17:47:57', '2023-03-01 17:47:57', '', 0, 'https://acfheadless.wpengine.local/?p=10', 0, 'post', '', 0),
(12, 4, '2022-09-22 16:23:49', '2022-09-22 16:23:49', '', 'krisztian-tabori-ZQf4jzkpz1k-unsplash', '', 'inherit', 'open', 'closed', '', 'krisztian-tabori-zqf4jzkpz1k-unsplash', '', '', '2022-09-22 16:23:49', '2022-09-22 16:23:49', '', 10, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/09/krisztian-tabori-ZQf4jzkpz1k-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 4, '2022-09-22 16:24:51', '2022-09-22 16:24:51', '', 'charlesdeluvio-la6DtkODelg-unsplash', '', 'inherit', 'open', 'closed', '', 'charlesdeluvio-la6dtkodelg-unsplash', '', '', '2022-09-22 16:24:51', '2022-09-22 16:24:51', '', 9, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/09/charlesdeluvio-la6DtkODelg-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 4, '2022-09-22 16:31:08', '2022-09-22 16:31:08', '', 'MR-3', '', 'publish', 'closed', 'closed', '', 'mr-3', '', '', '2022-09-22 16:31:08', '2022-09-22 16:31:08', '', 0, 'https://acfheadless.wpengine.local/?post_type=spacelaunch&#038;p=14', 0, 'spacelaunch', '', 0),
(15, 4, '2022-09-22 16:31:34', '2022-09-22 16:31:34', '', 'MR-4', '', 'publish', 'closed', 'closed', '', 'mr-4', '', '', '2022-09-22 16:31:34', '2022-09-22 16:31:34', '', 0, 'https://acfheadless.wpengine.local/?post_type=spacelaunch&#038;p=15', 0, 'spacelaunch', '', 0),
(16, 4, '2022-09-22 16:32:06', '2022-09-22 16:32:06', '', 'MA-6', '', 'publish', 'closed', 'closed', '', 'ma-6', '', '', '2022-09-22 16:32:06', '2022-09-22 16:32:06', '', 0, 'https://acfheadless.wpengine.local/?post_type=spacelaunch&#038;p=16', 0, 'spacelaunch', '', 0),
(17, 4, '2022-09-22 16:32:40', '2022-09-22 16:32:40', '', 'MA-7', '', 'publish', 'closed', 'closed', '', 'ma-7', '', '', '2022-09-22 16:32:40', '2022-09-22 16:32:40', '', 0, 'https://acfheadless.wpengine.local/?post_type=spacelaunch&#038;p=17', 0, 'spacelaunch', '', 0),
(18, 4, '2022-09-22 16:33:41', '2022-09-22 16:33:41', '', 'MA-8', '', 'publish', 'closed', 'closed', '', 'ma-8', '', '', '2022-09-22 16:33:42', '2022-09-22 16:33:42', '', 0, 'https://acfheadless.wpengine.local/?post_type=spacelaunch&#038;p=18', 0, 'spacelaunch', '', 0),
(20, 4, '2022-10-26 14:20:59', '2022-10-26 14:20:59', '', 'adi-goldstein-QfN0l0MZCyc-unsplash', '', 'inherit', 'open', 'closed', '', 'adi-goldstein-qfn0l0mzcyc-unsplash', '', '', '2022-10-26 14:20:59', '2022-10-26 14:20:59', '', 7, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/adi-goldstein-QfN0l0MZCyc-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 4, '2022-10-26 14:21:52', '2022-10-26 14:21:52', '', 'bruno-guerrero-vlLpPqOYg-8-unsplash', '', 'inherit', 'open', 'closed', '', 'bruno-guerrero-vllppqoyg-8-unsplash', '', '', '2022-10-26 14:21:52', '2022-10-26 14:21:52', '', 5, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/bruno-guerrero-vlLpPqOYg-8-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 4, '2022-10-26 14:27:52', '2022-10-26 14:27:52', '<!-- wp:paragraph -->\n<p>Tbh single-origin coffee retro vegan stumptown thundercats lo-fi gastropub. Selvage lyft tattooed, vibecession DIY direct trade hashtag kogi fam taiyaki semiotics YOLO before they sold out fingerstache. Man braid flexitarian iceland, flannel celiac echo park actually. Migas next level la croix 3 wolf moon live-edge. Kogi PBR&amp;B beard gochujang wolf. Occupy bitters kombucha church-key retro +1 heirloom asymmetrical wayfarers PBR&amp;B banh mi irony gentrify.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Microdosing subway tile cloud bread gluten-free echo park, godard green juice hell of gentrify. Venmo air plant four loko chicharrones, pop-up mlkshk wayfarers bicycle rights subway tile gluten-free migas VHS cliche raclette kitsch. Narwhal ugh deep v polaroid. Etsy keffiyeh mumblecore taxidermy master cleanse. Shoreditch farm-to-table marfa, knausgaard yes plz VHS man bun tilde venmo subway tile pinterest. Health goth PBR&amp;B big mood man bun yes plz freegan JOMO bodega boys humblebrag slow-carb coloring book viral.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":29,"width":512,"height":391,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/mike-kenneally-TD4DBagg2wE-unsplash-1024x781.jpg" alt="" class="wp-image-29" width="512" height="391"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@asthetik?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Mike Kenneally</a> on <a href="https://unsplash.com/s/photos/coffee?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Heirloom franzen freegan artisan, man braid polaroid palo santo glossier twee tilde everyday carry vaporware synth. Offal skateboard before they sold out kickstarter jean shorts selvage. Butcher cronut sustainable food truck cardigan distillery neutra typewriter venmo PBR&amp;B. Mixtape 90\'s keffiyeh hell of. Organic air plant dreamcatcher, quinoa VHS brunch pabst single-origin coffee twee man braid squid kogi. Helvetica Brooklyn migas street art art party seitan.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Vibecession farm-to-table subway tile woke chia cardigan. Disrupt kitsch deep v schlitz kogi chambray lumbersexual gastropub four dollar toast meggings brunch distillery prism. Palo santo succulents bushwick praxis. Messenger bag pabst hella cornhole yuccie synth woke microdosing leggings. Celiac XOXO tbh la croix YOLO pickled sriracha forage vexillologist marfa pinterest. Church-key XOXO tattooed 8-bit organic, praxis VHS hot chicken.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ethical tilde meditation lo-fi chicharrones, hoodie praxis fixie freegan bodega boys pour-over venmo sus. Shoreditch tilde cornhole, crucifix DIY keytar brunch lumbersexual prism pabst you probably haven\'t heard of them raw denim. Leggings mumblecore shabby chic, trust fund next level chia mlkshk fixie fit disrupt polaroid ennui subway tile farm-to-table you probably haven\'t heard of them. Man braid roof party master cleanse, next level viral fam selvage chillwave everyday carry jean shorts hammock etsy.</p>\n<!-- /wp:paragraph -->', 'Tbh Single-Origin Coffee PBR&amp;B', '', 'publish', 'open', 'open', '', 'tbh-single-origin-coffee', '', '', '2023-03-01 17:46:38', '2023-03-01 17:46:38', '', 0, 'https://acfheadless.wpengine.local/?p=22', 0, 'post', '', 0),
(23, 4, '2022-10-26 14:28:25', '2022-10-26 14:28:25', '<!-- wp:paragraph -->\n<p>Forage mixtape fanny pack. Fixie chartreuse unicorn pabst cardigan lyft stumptown neutra. Artisan mlkshk squid tonx plaid tofu ethical typewriter craft beer DSA chambray adaptogen drinking vinegar. Quinoa man bun pug mustache tofu stumptown VHS. Trust fund cornhole sustainable pickled tilde sartorial. Affogato gatekeep humblebrag art party, direct trade schlitz taxidermy chartreuse man braid tattooed single-origin coffee vice freegan. Plaid swag farm-to-table, humblebrag sustainable flexitarian mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":30,"width":512,"height":339,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/jose-luis-espindola-1L0o_htiew8-unsplash-1024x678.jpg" alt="" class="wp-image-30" width="512" height="339"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@cote_baires?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Jose Luis Espindola</a> on <a href="https://unsplash.com/s/photos/fanny-pack?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Gochujang af sustainable brunch. Praxis umami meggings, polaroid meditation crucifix distillery locavore vaporware cronut cliche gluten-free four dollar toast banjo stumptown. Mukbang bodega boys messenger bag cornhole. Truffaut mumblecore banh mi church-key af DSA austin ethical thundercats. Activated charcoal fingerstache viral irony vice pabst lomo tumblr prism semiotics. Deep v cornhole kombucha photo booth try-hard glossier. Microdosing shabby chic celiac shoreditch knausgaard lumbersexual vegan yr activated charcoal mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Pok pok cred subway tile bitters, waistcoat offal microdosing disrupt try-hard lomo raclette. Thundercats skateboard godard vice helvetica jean shorts polaroid before they sold out whatever locavore crucifix salvia offal brunch roof party. Bitters big mood Brooklyn hammock. Gentrify try-hard master cleanse actually poutine woke viral snackwave lo-fi. Lyft yes plz skateboard praxis. Enamel pin pabst paleo jianbing before they sold out polaroid iPhone.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Humblebrag ascot mlkshk shoreditch. Wayfarers portland authentic, affogato quinoa taxidermy microdosing bitters roof party green juice butcher. Ugh hot chicken fashion axe gentrify single-origin coffee. Letterpress blue bottle woke marfa chambray. Narwhal trust fund seitan tumeric raw denim hoodie vice single-origin coffee kale chips shabby chic austin direct trade copper mug flexitarian retro. Chia bruh whatever slow-carb subway tile kogi pickled jianbing snackwave. Gochujang brunch health goth, waistcoat adaptogen kickstarter +1 hell of twee.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Activated charcoal shabby chic fashion axe affogato art party, unicorn actually YOLO live-edge cray small batch taiyaki edison bulb farm-to-table normcore. Twee tonx tote bag, salvia DSA aesthetic you probably haven\'t heard of them woke shabby chic mustache lomo roof party hot chicken. Fixie banjo franzen chia fit. Photo booth swag cray iceland, meh activated charcoal slow-carb. Irony sriracha gatekeep, lomo taxidermy man bun artisan air plant chicharrones distillery four dollar toast. Biodiesel marfa narwhal, humblebrag offal deep v vexillologist franzen normcore kombucha pickled readymade hammock flexitarian. Vice YOLO cred waistcoat, meditation ugh occupy pug polaroid ramps pabst vibecession bitters yr.</p>\n<!-- /wp:paragraph -->', 'Forage Mixtape Fanny Pack', '', 'publish', 'open', 'open', '', 'forage-mixtape-fanny-pack', '', '', '2023-03-01 17:42:43', '2023-03-01 17:42:43', '', 0, 'https://acfheadless.wpengine.local/?p=23', 0, 'post', '', 0),
(24, 4, '2022-10-26 14:29:55', '2022-10-26 14:29:55', '<!-- wp:paragraph -->\n<p>Before they sold out forage mixtape fanny pack. Fixie chartreuse unicorn pabst cardigan lyft stumptown neutra. Artisan mlkshk squid tonx plaid tofu ethical typewriter craft beer DSA chambray adaptogen drinking vinegar. Quinoa man bun pug mustache tofu stumptown VHS. Trust fund cornhole sustainable pickled tilde sartorial. Affogato gatekeep humblebrag art party, direct trade schlitz taxidermy chartreuse man braid tattooed single-origin coffee vice freegan. Plaid swag farm-to-table, humblebrag sustainable flexitarian mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gochujang af sustainable brunch. Praxis umami meggings, polaroid meditation crucifix distillery locavore vaporware cronut cliche gluten-free four dollar toast banjo stumptown. Mukbang bodega boys messenger bag cornhole. Truffaut mumblecore banh mi church-key af DSA austin ethical thundercats. Activated charcoal fingerstache viral irony vice pabst lomo tumblr prism semiotics. Deep v cornhole kombucha photo booth try-hard glossier. Microdosing shabby chic celiac shoreditch knausgaard lumbersexual vegan yr activated charcoal mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"align":"center","id":25,"width":512,"height":342,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image aligncenter size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/kim-ick-JdfNXZAuk98-unsplash-1024x684.jpg" alt="" class="wp-image-25" width="512" height="342"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@kimick?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">kim ick</a> on <a href="https://unsplash.com/s/photos/affogato?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Pok pok cred subway tile bitters, waistcoat offal microdosing disrupt try-hard lomo raclette. Thundercats skateboard godard vice helvetica jean shorts polaroid before they sold out whatever locavore crucifix salvia offal brunch roof party. Bitters big mood Brooklyn hammock. Gentrify try-hard master cleanse actually poutine woke viral snackwave lo-fi. Lyft yes plz skateboard praxis. Enamel pin pabst paleo jianbing before they sold out polaroid iPhone.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Humblebrag ascot mlkshk shoreditch. Wayfarers portland authentic, affogato quinoa taxidermy microdosing bitters roof party green juice butcher. Ugh hot chicken fashion axe gentrify single-origin coffee. Letterpress blue bottle woke marfa chambray. Narwhal trust fund seitan tumeric raw denim hoodie vice single-origin coffee kale chips shabby chic austin direct trade copper mug flexitarian retro. Chia bruh whatever slow-carb subway tile kogi pickled jianbing snackwave. Gochujang brunch health goth, waistcoat adaptogen kickstarter +1 hell of twee.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Activated charcoal shabby chic fashion axe affogato art party, unicorn actually YOLO live-edge cray small batch taiyaki edison bulb farm-to-table normcore. Twee tonx tote bag, salvia DSA aesthetic you probably haven\'t heard of them woke shabby chic mustache lomo roof party hot chicken. Fixie banjo franzen chia fit. Photo booth swag cray iceland, meh activated charcoal slow-carb. Irony sriracha gatekeep, lomo taxidermy man bun artisan air plant chicharrones distillery four dollar toast. Biodiesel marfa narwhal, humblebrag offal deep v vexillologist franzen normcore kombucha pickled readymade hammock flexitarian. Vice YOLO cred waistcoat, meditation ugh occupy pug polaroid ramps pabst vibecession bitters yr.</p>\n<!-- /wp:paragraph -->', 'Affogato Quinoa Taxidermy', '', 'publish', 'open', 'open', '', 'affogato-quinoa-taxidermy', '', '', '2023-03-01 17:37:19', '2023-03-01 17:37:19', '', 0, 'https://acfheadless.wpengine.local/?p=24', 0, 'post', '', 0),
(25, 4, '2022-10-26 14:31:00', '2022-10-26 14:31:00', '', 'kim-ick-JdfNXZAuk98-unsplash', '', 'inherit', 'open', 'closed', '', 'kim-ick-jdfnxzauk98-unsplash', '', '', '2022-10-26 14:31:00', '2022-10-26 14:31:00', '', 24, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/kim-ick-JdfNXZAuk98-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 4, '2022-10-26 14:34:07', '2022-10-26 14:34:07', '<!-- wp:paragraph -->\n<p>Artisan air plant chicharrones distillery four dollar toast. Biodiesel marfa narwhal, humblebrag offal deep v vexillologist franzen normcore kombucha pickled readymade hammock flexitarian. Vice YOLO cred waistcoat, meditation ugh occupy pug polaroid ramps pabst vibecession bitters yr. Before they sold out forage mixtape fanny pack. Fixie chartreuse unicorn pabst cardigan lyft stumptown neutra. Artisan mlkshk squid tonx plaid tofu ethical typewriter craft beer DSA chambray adaptogen drinking vinegar. Quinoa man bun pug mustache tofu stumptown VHS. Trust fund cornhole sustainable pickled tilde sartorial. Affogato gatekeep humblebrag art party, direct trade schlitz taxidermy chartreuse man braid tattooed single-origin coffee vice freegan. Plaid swag farm-to-table, humblebrag sustainable flexitarian mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":27,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/chen-yij-lOTEL9Vfz7k-unsplash-scaled.jpg" alt="An airplant in a sunny apartment window sill" class="wp-image-27"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@jhenyi?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Chen Yij</a> on <a href="https://unsplash.com/s/photos/air-plant?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Artisan air plant chicharrones distillery four dollar toast. Biodiesel marfa narwhal, humblebrag offal deep v vexillologist franzen normcore kombucha pickled readymade hammock flexitarian. Vice YOLO cred waistcoat, meditation ugh occupy pug polaroid ramps pabst vibecession bitters yr. Before they sold out forage mixtape fanny pack. Fixie chartreuse unicorn pabst cardigan lyft stumptown neutra. Artisan mlkshk squid tonx plaid tofu ethical typewriter craft beer DSA chambray adaptogen drinking vinegar. Quinoa man bun pug mustache tofu stumptown VHS. Trust fund cornhole sustainable pickled tilde sartorial. Affogato gatekeep humblebrag art party, direct trade schlitz taxidermy chartreuse man braid tattooed single-origin coffee vice freegan. Plaid swag farm-to-table, humblebrag sustainable flexitarian mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gochujang af sustainable brunch. Praxis umami meggings, polaroid meditation crucifix distillery locavore vaporware cronut cliche gluten-free four dollar toast banjo stumptown. Mukbang bodega boys messenger bag cornhole. Truffaut mumblecore banh mi church-key af DSA austin ethical thundercats. Activated charcoal fingerstache viral irony vice pabst lomo tumblr prism semiotics. Deep v cornhole kombucha photo booth try-hard glossier. Microdosing shabby chic celiac shoreditch knausgaard lumbersexual vegan yr activated charcoal mixtape.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"align":"center","id":25,"width":512,"height":342,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image aligncenter size-large is-resized"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/kim-ick-JdfNXZAuk98-unsplash-1024x684.jpg" alt="" class="wp-image-25" width="512" height="342"/><figcaption class="wp-element-caption">Photo by <a href="https://unsplash.com/@kimick?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">kim ick</a> on <a href="https://unsplash.com/s/photos/affogato?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Pok pok cred subway tile bitters, waistcoat offal microdosing disrupt try-hard lomo raclette. Thundercats skateboard godard vice helvetica jean shorts polaroid before they sold out whatever locavore crucifix salvia offal brunch roof party. Bitters big mood Brooklyn hammock. Gentrify try-hard master cleanse actually poutine woke viral snackwave lo-fi. Lyft yes plz skateboard praxis. Enamel pin pabst paleo jianbing before they sold out polaroid iPhone.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Humblebrag ascot mlkshk shoreditch. Wayfarers portland authentic, affogato quinoa taxidermy microdosing bitters roof party green juice butcher. Ugh hot chicken fashion axe gentrify single-origin coffee. Letterpress blue bottle woke marfa chambray. Narwhal trust fund seitan tumeric raw denim hoodie vice single-origin coffee kale chips shabby chic austin direct trade copper mug flexitarian retro. Chia bruh whatever slow-carb subway tile kogi pickled jianbing snackwave. Gochujang brunch health goth, waistcoat adaptogen kickstarter +1 hell of twee.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Activated charcoal shabby chic fashion axe affogato art party, unicorn actually YOLO live-edge cray small batch taiyaki edison bulb farm-to-table normcore. Twee tonx tote bag, salvia DSA aesthetic you probably haven\'t heard of them woke shabby chic mustache lomo roof party hot chicken. Fixie banjo franzen chia fit. Photo booth swag cray iceland, meh activated charcoal slow-carb. Irony sriracha gatekeep, lomo taxidermy man bun. Artisan air plant chicharrones distillery four dollar toast. Biodiesel marfa narwhal, humblebrag offal deep v vexillologist franzen normcore kombucha pickled readymade hammock flexitarian. Vice YOLO cred waistcoat, meditation ugh occupy pug polaroid ramps pabst vibecession bitters yr.</p>\n<!-- /wp:paragraph -->', 'Artisan Air Plant Chicharrones', '', 'publish', 'open', 'open', '', 'artisan-air-plant-chicharrones', '', '', '2023-03-01 17:36:47', '2023-03-01 17:36:47', '', 0, 'https://acfheadless.wpengine.local/?p=26', 0, 'post', '', 0),
(27, 4, '2022-10-26 14:33:48', '2022-10-26 14:33:48', '', 'chen-yij-lOTEL9Vfz7k-unsplash', '', 'inherit', 'open', 'closed', '', 'chen-yij-lotel9vfz7k-unsplash', '', '', '2022-10-26 14:33:48', '2022-10-26 14:33:48', '', 26, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/chen-yij-lOTEL9Vfz7k-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 4, '2022-10-26 16:36:38', '2022-10-26 16:36:38', '', 'mike-kenneally-TD4DBagg2wE-unsplash', '', 'inherit', 'open', 'closed', '', 'mike-kenneally-td4dbagg2we-unsplash', '', '', '2022-10-26 16:36:38', '2022-10-26 16:36:38', '', 22, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/mike-kenneally-TD4DBagg2wE-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(30, 4, '2022-10-26 16:38:10', '2022-10-26 16:38:10', '', 'jose-luis-espindola-1L0o_htiew8-unsplash', '', 'inherit', 'open', 'closed', '', 'jose-luis-espindola-1l0o_htiew8-unsplash', '', '', '2022-10-26 16:38:10', '2022-10-26 16:38:10', '', 23, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/jose-luis-espindola-1L0o_htiew8-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 4, '2022-10-26 16:42:41', '2022-10-26 16:42:41', '', 'lucas-lenzi-zeT_i6av9rU-unsplash', '', 'inherit', 'open', 'closed', '', 'lucas-lenzi-zet_i6av9ru-unsplash', '', '', '2022-10-26 16:42:41', '2022-10-26 16:42:41', '', 10, 'https://acfheadless.wpengine.local/wp-content/uploads/2022/10/lucas-lenzi-zeT_i6av9rU-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 4, '2022-11-07 13:17:21', '2022-11-07 13:17:21', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dui magna, tempus eget mi id, bibendum molestie metus. Donec ut tortor dui. Integer tincidunt, sapien sed tincidunt pellentesque, turpis dolor gravida ipsum, sit amet rhoncus mauris justo et nibh. Ut ornare magna augue, id facilisis lorem vehicula a. Nulla quis elementum massa. Cras lobortis feugiat suscipit. Duis mollis massa at lacus lobortis, ut tristique eros fringilla. Maecenas quis libero vehicula, lobortis turpis id, porttitor est. Morbi volutpat sodales turpis ac iaculis. Curabitur mattis elit odio, pulvinar eleifend metus finibus vitae. Phasellus ornare magna vitae nulla convallis pulvinar. Suspendisse ligula sem, consequat at congue sed, cursus bibendum dui. Etiam posuere congue elit, vel pellentesque ipsum efficitur lacinia. Nulla malesuada dui quis dictum malesuada.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Sub Heading</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Donec euismod, metus vel ornare tincidunt, massa magna iaculis purus, non egestas libero ex ut mi. Vestibulum mollis sollicitudin metus, sed tempus diam posuere ut. Nam pharetra, elit sit amet lobortis maximus, risus ex egestas ex, id fringilla leo dui ut mi. Fusce dapibus consequat massa sit amet rhoncus. Pellentesque ut leo vel quam feugiat semper quis id dui. Maecenas tempor, mauris vel eleifend ornare, diam neque faucibus turpis, id semper sem sapien et magna. Nunc fermentum luctus ligula, sit amet euismod est molestie vitae. Nullam commodo enim ex, nec faucibus sem suscipit quis. Sed id ligula a nisl rhoncus eleifend.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":25,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/kim-ick-JdfNXZAuk98-unsplash-1024x684.jpg" alt="" class="wp-image-25"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sed a nisl felis. Sed rhoncus eleifend neque in molestie. Proin nec augue et velit blandit laoreet semper ut risus. Proin efficitur lorem quis porttitor iaculis. Suspendisse quis nulla finibus massa interdum porta et nec diam. Fusce in turpis ac sapien lobortis imperdiet ut in urna. Vivamus a sollicitudin diam.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>First Thing</li><li>Second Thing</li><li>Third Thing</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Nullam sodales pharetra neque, eu venenatis mi. Nam pharetra ante a nibh semper tempus. Donec pharetra interdum rutrum. Aenean vel neque et quam porttitor feugiat. Nunc elementum id lacus at mattis. Etiam lobortis risus nec eros interdum, a molestie sapien imperdiet. Sed hendrerit lorem id nulla tincidunt, ut euismod ex malesuada. Pellentesque ac dui et augue porttitor tempor. Nunc tincidunt condimentum mauris quis vehicula. Sed tincidunt volutpat dolor at viverra.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Suspendisse rhoncus dui vel gravida viverra. Integer bibendum vulputate tellus, in cursus diam eleifend eget. Duis nisi elit, fermentum vitae urna vel, volutpat tempor elit. Quisque molestie sed sapien vitae scelerisque. Phasellus condimentum turpis sit amet libero faucibus, vel porta enim lacinia. Proin convallis faucibus posuere. Quisque tristique vel ligula eu tempor. Nullam vel magna sit amet sem dictum dignissim sed in felis. Cras vitae felis sodales velit imperdiet accumsan. Vestibulum lacinia mi vitae ligula mattis tempor. Nunc convallis turpis vitae dui tristique accumsan. Donec id sem et tellus blandit auctor quis vulputate felis. Morbi ut congue enim. Duis iaculis nisl quis consectetur euismod. Morbi interdum accumsan tincidunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Parent', '', 'publish', 'closed', 'closed', '', 'parent', '', '', '2022-11-08 17:27:08', '2022-11-08 17:27:08', '', 0, 'https://acfheadless.wpengine.local/?page_id=38', 0, 'page', '', 0),
(39, 4, '2022-11-07 13:17:49', '2022-11-07 13:17:49', '<!-- wp:paragraph -->\n<p>Here is some content about child page 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dui magna, tempus eget mi id, bibendum molestie metus. Donec ut tortor dui. Integer tincidunt, sapien sed tincidunt pellentesque, turpis dolor gravida ipsum, sit amet rhoncus mauris justo et nibh. Ut ornare magna augue, id facilisis lorem vehicula a. Nulla quis elementum massa. Cras lobortis feugiat suscipit. Duis mollis massa at lacus lobortis, ut tristique eros fringilla. Maecenas quis libero vehicula, lobortis turpis id, porttitor est. Morbi volutpat sodales turpis ac iaculis. Curabitur mattis elit odio, pulvinar eleifend metus finibus vitae. Phasellus ornare magna vitae nulla convallis pulvinar. Suspendisse ligula sem, consequat at congue sed, cursus bibendum dui. Etiam posuere congue elit, vel pellentesque ipsum efficitur lacinia. Nulla malesuada dui quis dictum malesuada.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Sub Heading</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Donec euismod, metus vel ornare tincidunt, massa magna iaculis purus, non egestas libero ex ut mi. Vestibulum mollis sollicitudin metus, sed tempus diam posuere ut. Nam pharetra, elit sit amet lobortis maximus, risus ex egestas ex, id fringilla leo dui ut mi. Fusce dapibus consequat massa sit amet rhoncus. Pellentesque ut leo vel quam feugiat semper quis id dui. Maecenas tempor, mauris vel eleifend ornare, diam neque faucibus turpis, id semper sem sapien et magna. Nunc fermentum luctus ligula, sit amet euismod est molestie vitae. Nullam commodo enim ex, nec faucibus sem suscipit quis. Sed id ligula a nisl rhoncus eleifend.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":20,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/adi-goldstein-QfN0l0MZCyc-unsplash-1024x683.jpg" alt="" class="wp-image-20"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sed a nisl felis. Sed rhoncus eleifend neque in molestie. Proin nec augue et velit blandit laoreet semper ut risus. Proin efficitur lorem quis porttitor iaculis. Suspendisse quis nulla finibus massa interdum porta et nec diam. Fusce in turpis ac sapien lobortis imperdiet ut in urna. Vivamus a sollicitudin diam.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>First Thing</li><li>Second Thing</li><li>Third Thing</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Nullam sodales pharetra neque, eu venenatis mi. Nam pharetra ante a nibh semper tempus. Donec pharetra interdum rutrum. Aenean vel neque et quam porttitor feugiat. Nunc elementum id lacus at mattis. Etiam lobortis risus nec eros interdum, a molestie sapien imperdiet. Sed hendrerit lorem id nulla tincidunt, ut euismod ex malesuada. Pellentesque ac dui et augue porttitor tempor. Nunc tincidunt condimentum mauris quis vehicula. Sed tincidunt volutpat dolor at viverra.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Suspendisse rhoncus dui vel gravida viverra. Integer bibendum vulputate tellus, in cursus diam eleifend eget. Duis nisi elit, fermentum vitae urna vel, volutpat tempor elit. Quisque molestie sed sapien vitae scelerisque. Phasellus condimentum turpis sit amet libero faucibus, vel porta enim lacinia. Proin convallis faucibus posuere. Quisque tristique vel ligula eu tempor. Nullam vel magna sit amet sem dictum dignissim sed in felis. Cras vitae felis sodales velit imperdiet accumsan. Vestibulum lacinia mi vitae ligula mattis tempor. Nunc convallis turpis vitae dui tristique accumsan. Donec id sem et tellus blandit auctor quis vulputate felis. Morbi ut congue enim. Duis iaculis nisl quis consectetur euismod. Morbi interdum accumsan tincidunt.</p>\n<!-- /wp:paragraph -->', 'Child Page One', '', 'publish', 'closed', 'closed', '', 'child-one', '', '', '2022-11-08 17:28:32', '2022-11-08 17:28:32', '', 38, 'https://acfheadless.wpengine.local/?page_id=39', 0, 'page', '', 0),
(40, 4, '2022-11-07 13:18:04', '2022-11-07 13:18:04', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc dui magna, tempus eget mi id, bibendum molestie metus. Donec ut tortor dui. Integer tincidunt, sapien sed tincidunt pellentesque, turpis dolor gravida ipsum, sit amet rhoncus mauris justo et nibh. Ut ornare magna augue, id facilisis lorem vehicula a. Nulla quis elementum massa. Cras lobortis feugiat suscipit. Duis mollis massa at lacus lobortis, ut tristique eros fringilla. Maecenas quis libero vehicula, lobortis turpis id, porttitor est. Morbi volutpat sodales turpis ac iaculis. Curabitur mattis elit odio, pulvinar eleifend metus finibus vitae. Phasellus ornare magna vitae nulla convallis pulvinar. Suspendisse ligula sem, consequat at congue sed, cursus bibendum dui. Etiam posuere congue elit, vel pellentesque ipsum efficitur lacinia. Nulla malesuada dui quis dictum malesuada.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Sub Heading</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Donec euismod, metus vel ornare tincidunt, massa magna iaculis purus, non egestas libero ex ut mi. Vestibulum mollis sollicitudin metus, sed tempus diam posuere ut. Nam pharetra, elit sit amet lobortis maximus, risus ex egestas ex, id fringilla leo dui ut mi. Fusce dapibus consequat massa sit amet rhoncus. Pellentesque ut leo vel quam feugiat semper quis id dui. Maecenas tempor, mauris vel eleifend ornare, diam neque faucibus turpis, id semper sem sapien et magna. Nunc fermentum luctus ligula, sit amet euismod est molestie vitae. Nullam commodo enim ex, nec faucibus sem suscipit quis. Sed id ligula a nisl rhoncus eleifend.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":21,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://acfheadless.wpengine.local/wp-content/uploads/2022/10/bruno-guerrero-vlLpPqOYg-8-unsplash-1024x683.jpg" alt="" class="wp-image-21"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sed a nisl felis. Sed rhoncus eleifend neque in molestie. Proin nec augue et velit blandit laoreet semper ut risus. Proin efficitur lorem quis porttitor iaculis. Suspendisse quis nulla finibus massa interdum porta et nec diam. Fusce in turpis ac sapien lobortis imperdiet ut in urna. Vivamus a sollicitudin diam.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>First Thing</li><li>Second Thing</li><li>Third Thing</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Nullam sodales pharetra neque, eu venenatis mi. Nam pharetra ante a nibh semper tempus. Donec pharetra interdum rutrum. Aenean vel neque et quam porttitor feugiat. Nunc elementum id lacus at mattis. Etiam lobortis risus nec eros interdum, a molestie sapien imperdiet. Sed hendrerit lorem id nulla tincidunt, ut euismod ex malesuada. Pellentesque ac dui et augue porttitor tempor. Nunc tincidunt condimentum mauris quis vehicula. Sed tincidunt volutpat dolor at viverra.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Suspendisse rhoncus dui vel gravida viverra. Integer bibendum vulputate tellus, in cursus diam eleifend eget. Duis nisi elit, fermentum vitae urna vel, volutpat tempor elit. Quisque molestie sed sapien vitae scelerisque. Phasellus condimentum turpis sit amet libero faucibus, vel porta enim lacinia. Proin convallis faucibus posuere. Quisque tristique vel ligula eu tempor. Nullam vel magna sit amet sem dictum dignissim sed in felis. Cras vitae felis sodales velit imperdiet accumsan. Vestibulum lacinia mi vitae ligula mattis tempor. Nunc convallis turpis vitae dui tristique accumsan. Donec id sem et tellus blandit auctor quis vulputate felis. Morbi ut congue enim. Duis iaculis nisl quis consectetur euismod. Morbi interdum accumsan tincidunt.</p>\n<!-- /wp:paragraph -->', 'Child Page 2', '', 'publish', 'closed', 'closed', '', 'child-page-2', '', '', '2022-11-08 17:28:10', '2022-11-08 17:28:10', '', 38, 'https://acfheadless.wpengine.local/?page_id=40', 0, 'page', '', 0),
(41, 4, '2022-11-18 17:32:32', '2022-11-07 19:23:11', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2022-11-18 17:32:32', '2022-11-18 17:32:32', '', 0, 'https://acfheadless.wpengine.local/?p=41', 1, 'nav_menu_item', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(42, 4, '2022-11-18 17:32:32', '2022-11-07 19:23:11', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2022-11-18 17:32:32', '2022-11-18 17:32:32', '', 38, 'https://acfheadless.wpengine.local/?p=42', 2, 'nav_menu_item', '', 0),
(43, 4, '2022-11-18 17:32:32', '2022-11-07 19:23:11', ' ', '', '', 'publish', 'closed', 'closed', '', '43', '', '', '2022-11-18 17:32:32', '2022-11-18 17:32:32', '', 38, 'https://acfheadless.wpengine.local/?p=43', 3, 'nav_menu_item', '', 0),
(52, 4, '2022-11-21 19:46:05', '2022-11-21 19:46:05', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_62194e01159c2', '', '', '2022-11-21 19:46:05', '2022-11-21 19:46:05', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=52', 0, 'acf-field', '', 0),
(53, 4, '2022-11-21 19:46:05', '2022-11-21 19:46:05', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_62194df9159c1', '', '', '2022-11-21 19:46:05', '2022-11-21 19:46:05', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=53', 1, 'acf-field', '', 0),
(54, 4, '2022-11-21 19:46:05', '2022-11-21 19:46:05', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_62194e0f159c3', '', '', '2022-11-21 19:46:05', '2022-11-21 19:46:05', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=54', 2, 'acf-field', '', 0),
(55, 4, '2022-11-21 19:46:05', '2022-11-21 19:46:05', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_62194e14159c4', '', '', '2022-11-21 19:46:05', '2022-11-21 19:46:05', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=55', 3, 'acf-field', '', 0),
(56, 4, '2022-11-21 19:46:05', '2022-11-21 19:46:05', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'CTA1', 'cta1', 'publish', 'closed', 'closed', '', 'field_62194e26159c5', '', '', '2022-11-21 19:46:05', '2022-11-21 19:46:05', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=56', 4, 'acf-field', '', 0),
(57, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'CTA2', 'cta2', 'publish', 'closed', 'closed', '', 'field_62194e37159c6', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=57', 5, 'acf-field', '', 0),
(59, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_62194e6d159c8', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=59', 0, 'acf-field', '', 0),
(60, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:9:"post_type";a:1:{i:0;s:10:"attachment";}s:8:"taxonomy";s:0:"";s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Logos', 'logos', 'publish', 'closed', 'closed', '', 'field_62194e75159c9', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=60', 1, 'acf-field', '', 0),
(62, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_62195352b1b3c', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=62', 0, 'acf-field', '', 0),
(63, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_62195356b1b3d', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=63', 1, 'acf-field', '', 0),
(64, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Product1', 'product1', 'publish', 'closed', 'closed', '', 'field_6219535bb1b3e', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=64', 2, 'acf-field', '', 0),
(65, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_62195370b1b3f', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 64, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=65', 0, 'acf-field', '', 0),
(66, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_62195375b1b40', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 64, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=66', 1, 'acf-field', '', 0),
(67, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_6219537cb1b41', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 64, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=67', 2, 'acf-field', '', 0),
(68, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_62195387b1b42', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 64, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=68', 3, 'acf-field', '', 0),
(69, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Product2', 'product2', 'publish', 'closed', 'closed', '', 'field_621953b0d8fb8', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=69', 3, 'acf-field', '', 0),
(70, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621953b0d8fb9', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 69, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=70', 0, 'acf-field', '', 0),
(71, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621953b0d8fba', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 69, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=71', 1, 'acf-field', '', 0),
(72, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:0:"";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_621953b0d8fbb', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 69, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=72', 2, 'acf-field', '', 0),
(73, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:0:"";s:12:"preview_size";s:6:"medium";s:7:"library";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621953b0d8fbc', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 69, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=73', 3, 'acf-field', '', 0),
(74, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Product3', 'product3', 'publish', 'closed', 'closed', '', 'field_621953b7d8fbd', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=74', 4, 'acf-field', '', 0),
(75, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621953b7d8fbe', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 74, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=75', 0, 'acf-field', '', 0),
(76, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621953b7d8fbf', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 74, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=76', 1, 'acf-field', '', 0),
(77, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_621953b7d8fc0', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 74, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=77', 2, 'acf-field', '', 0),
(78, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621953b7d8fc1', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 74, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=78', 3, 'acf-field', '', 0),
(80, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_62194ec6159cb', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=80', 0, 'acf-field', '', 0),
(81, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_62194ecb159cc', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=81', 1, 'acf-field', '', 0),
(82, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_62194edd159cd', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=82', 2, 'acf-field', '', 0),
(83, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Feature1', 'feature1', 'publish', 'closed', 'closed', '', 'field_62194eef159ce', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=83', 3, 'acf-field', '', 0),
(84, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_62194ef9159cf', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 83, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=84', 0, 'acf-field', '', 0),
(85, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_62194f04159d0', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 83, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=85', 1, 'acf-field', '', 0),
(86, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_62194f09159d1', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 83, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=86', 2, 'acf-field', '', 0),
(87, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_62194f0f159d2', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 83, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=87', 3, 'acf-field', '', 0),
(88, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_62194f19159d3', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 83, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=88', 4, 'acf-field', '', 0),
(89, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Feature2', 'feature2', 'publish', 'closed', 'closed', '', 'field_62194f30f6158', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=89', 4, 'acf-field', '', 0),
(90, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_62194f30f6159', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 89, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=90', 0, 'acf-field', '', 0),
(91, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_62194f30f615a', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 89, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=91', 1, 'acf-field', '', 0),
(92, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_62194f30f615b', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 89, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=92', 2, 'acf-field', '', 0),
(93, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_62194f30f615c', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 89, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=93', 3, 'acf-field', '', 0),
(94, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_62194f30f615d', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 89, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=94', 4, 'acf-field', '', 0),
(96, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd2022e592', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=96', 0, 'acf-field', '', 0),
(97, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621cd2062e593', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=97', 1, 'acf-field', '', 0),
(98, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Benefit1', 'benefit1', 'publish', 'closed', 'closed', '', 'field_621cd20d2e594', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=98', 2, 'acf-field', '', 0),
(99, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd2212e595', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 98, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=99', 0, 'acf-field', '', 0),
(100, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621cd2262e596', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 98, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=100', 1, 'acf-field', '', 0),
(101, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621cd22a2e597', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 98, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=101', 2, 'acf-field', '', 0),
(102, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Benefit2', 'benefit2', 'publish', 'closed', 'closed', '', 'field_621cd23e78ffd', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=102', 3, 'acf-field', '', 0),
(103, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd23e78ffe', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 102, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=103', 0, 'acf-field', '', 0),
(104, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621cd23e78fff', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 102, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=104', 1, 'acf-field', '', 0),
(105, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621cd23e79000', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 102, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=105', 2, 'acf-field', '', 0),
(106, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Benefit3', 'benefit3', 'publish', 'closed', 'closed', '', 'field_621cd251ab4d0', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=106', 4, 'acf-field', '', 0),
(107, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd251ab4d1', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 106, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=107', 0, 'acf-field', '', 0),
(108, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621cd251ab4d2', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 106, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=108', 1, 'acf-field', '', 0),
(109, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621cd251ab4d3', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 106, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=109', 2, 'acf-field', '', 0),
(111, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_621cd3d6887d3', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=111', 0, 'acf-field', '', 0),
(112, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd3da887d4', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=112', 1, 'acf-field', '', 0),
(113, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621cd3de887d5', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=113', 2, 'acf-field', '', 0),
(114, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621cd3e6887d6', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=114', 3, 'acf-field', '', 0),
(115, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Icon', 'icon', 'publish', 'closed', 'closed', '', 'field_621cd3f2887d7', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=115', 4, 'acf-field', '', 0),
(116, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_621cd406887d8', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=116', 5, 'acf-field', '', 0),
(117, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Stat1', 'stat1', 'publish', 'closed', 'closed', '', 'field_621cd417f0677', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=117', 6, 'acf-field', '', 0),
(118, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Value', 'value', 'publish', 'closed', 'closed', '', 'field_621cd421f0678', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 117, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=118', 0, 'acf-field', '', 0),
(119, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Label', 'label', 'publish', 'closed', 'closed', '', 'field_621cd426f0679', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 117, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=119', 1, 'acf-field', '', 0),
(120, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Stat2', 'stat2', 'publish', 'closed', 'closed', '', 'field_621cd43402fbd', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=120', 7, 'acf-field', '', 0),
(121, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Value', 'value', 'publish', 'closed', 'closed', '', 'field_621cd43402fbe', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 120, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=121', 0, 'acf-field', '', 0),
(122, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Label', 'label', 'publish', 'closed', 'closed', '', 'field_621cd43402fbf', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 120, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=122', 1, 'acf-field', '', 0),
(123, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Stat3', 'stat3', 'publish', 'closed', 'closed', '', 'field_621cd43e02fc0', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=123', 8, 'acf-field', '', 0),
(124, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Value', 'value', 'publish', 'closed', 'closed', '', 'field_621cd43e02fc1', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 123, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=124', 0, 'acf-field', '', 0),
(125, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Label', 'label', 'publish', 'closed', 'closed', '', 'field_621cd43e02fc2', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 123, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=125', 1, 'acf-field', '', 0),
(127, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_621cd69c07997', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=127', 0, 'acf-field', '', 0),
(128, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd6a307998', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=128', 1, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(129, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Testimonial1', 'testimonial1', 'publish', 'closed', 'closed', '', 'field_621cd6ae07999', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=129', 2, 'acf-field', '', 0),
(130, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Quote', 'quote', 'publish', 'closed', 'closed', '', 'field_621cd71b0799a', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 129, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=130', 0, 'acf-field', '', 0),
(131, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Source', 'source', 'publish', 'closed', 'closed', '', 'field_621cd71f0799b', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 129, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=131', 1, 'acf-field', '', 0),
(132, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Avatar', 'avatar', 'publish', 'closed', 'closed', '', 'field_621cd7230799c', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 129, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=132', 2, 'acf-field', '', 0),
(133, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Testimonial2', 'testimonial2', 'publish', 'closed', 'closed', '', 'field_621cd73821945', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=133', 3, 'acf-field', '', 0),
(134, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Quote', 'quote', 'publish', 'closed', 'closed', '', 'field_621cd73821946', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 133, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=134', 0, 'acf-field', '', 0),
(135, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Source', 'source', 'publish', 'closed', 'closed', '', 'field_621cd73821947', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 133, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=135', 1, 'acf-field', '', 0),
(136, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:0:"";s:12:"preview_size";s:6:"medium";s:7:"library";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Avatar', 'avatar', 'publish', 'closed', 'closed', '', 'field_621cd73821948', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 133, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=136', 2, 'acf-field', '', 0),
(137, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Testimonial3', 'testimonial3', 'publish', 'closed', 'closed', '', 'field_621cd74221949', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=137', 4, 'acf-field', '', 0),
(138, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Quote', 'quote', 'publish', 'closed', 'closed', '', 'field_621cd7422194a', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 137, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=138', 0, 'acf-field', '', 0),
(139, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Source', 'source', 'publish', 'closed', 'closed', '', 'field_621cd7422194b', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 137, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=139', 1, 'acf-field', '', 0),
(140, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:0:"";s:12:"preview_size";s:6:"medium";s:7:"library";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Avatar', 'avatar', 'publish', 'closed', 'closed', '', 'field_621cd7422194c', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 137, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=140', 2, 'acf-field', '', 0),
(141, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Testimonial4', 'testimonial4', 'publish', 'closed', 'closed', '', 'field_621cd7492194d', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=141', 5, 'acf-field', '', 0),
(142, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Quote', 'quote', 'publish', 'closed', 'closed', '', 'field_621cd7492194e', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 141, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=142', 0, 'acf-field', '', 0),
(143, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Source', 'source', 'publish', 'closed', 'closed', '', 'field_621cd7492194f', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 141, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=143', 1, 'acf-field', '', 0),
(144, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Avatar', 'avatar', 'publish', 'closed', 'closed', '', 'field_621cd74921950', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 141, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=144', 2, 'acf-field', '', 0),
(146, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Kicker', 'kicker', 'publish', 'closed', 'closed', '', 'field_621cd834da61b', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=146', 0, 'acf-field', '', 0),
(147, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'heading', 'publish', 'closed', 'closed', '', 'field_621cd840da61c', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=147', 1, 'acf-field', '', 0),
(148, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_621cd844da61d', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=148', 2, 'acf-field', '', 0),
(149, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_621cd84fda61e', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=149', 3, 'acf-field', '', 0),
(150, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link1', 'link1', 'publish', 'closed', 'closed', '', 'field_621cd858da61f', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=150', 4, 'acf-field', '', 0),
(151, 4, '2022-11-21 19:46:06', '2022-11-21 19:46:06', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:5:"array";}', 'Link2', 'link2', 'publish', 'closed', 'closed', '', 'field_621cd86eda621', '', '', '2022-11-21 19:46:06', '2022-11-21 19:46:06', '', 49, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=151', 5, 'acf-field', '', 0),
(161, 4, '2022-11-28 20:57:13', '2022-11-28 20:57:13', '{"action_type":"NON_NODE_ROOT_FIELDS","title":"Update Setting:  active_plugins","node_id":"update_non_node_root_field","relay_id":"update_non_node_root_field","graphql_single_name":"update_non_node_root_field","graphql_plural_name":"update_non_node_root_field","status":"update_non_node_root_field"}', 'Update Setting:  active_plugins', '', 'publish', 'closed', 'closed', '', 'update-setting-active_plugins-1669669033', '', '', '2023-02-25 20:25:36', '2023-02-25 20:25:36', '', 0, 'https://acfheadless.wpengine.local/?post_type=action_monitor&#038;p=161', 0, 'action_monitor', '', 0),
(162, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:12:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:1;s:15:"show_in_graphql";i:1;s:18:"graphql_field_name";s:13:"postResources";s:37:"map_graphql_types_from_location_rules";i:0;s:13:"graphql_types";s:0:"";}', 'Post Resources', 'post-resources', 'trash', 'closed', 'closed', '', 'group_638520b93d809__trashed', '', '', '2023-02-25 20:27:08', '2023-02-25 20:27:08', '', 0, 'https://acfheadless.wpengine.local/?post_type=acf-field-group&#038;p=162', 0, 'acf-field-group', '', 0),
(163, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"table";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:0:"";s:12:"button_label";s:0:"";s:13:"rows_per_page";i:20;}', 'Blog Posts', 'blog_posts', 'trash', 'closed', 'closed', '', 'field_638520ba12627__trashed', '', '', '2023-02-25 20:27:08', '2023-02-25 20:27:08', '', 162, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=163', 0, 'acf-field', '', 0),
(164, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_6385212b12628', '', '', '2022-11-28 21:02:59', '2022-11-28 21:02:59', '', 163, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=164', 0, 'acf-field', '', 0),
(165, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'URL', 'url', 'publish', 'closed', 'closed', '', 'field_6385213d12629', '', '', '2022-11-28 21:02:59', '2022-11-28 21:02:59', '', 163, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=165', 1, 'acf-field', '', 0),
(166, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:6:"layout";s:5:"table";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:0:"";s:12:"button_label";s:0:"";s:13:"rows_per_page";i:20;}', 'Videos', 'videos', 'trash', 'closed', 'closed', '', 'field_638521521262a__trashed', '', '', '2023-02-25 20:27:08', '2023-02-25 20:27:08', '', 162, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=166', 1, 'acf-field', '', 0),
(167, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_6385217f1262b', '', '', '2022-11-28 21:02:59', '2022-11-28 21:02:59', '', 166, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=167', 0, 'acf-field', '', 0),
(168, 4, '2022-11-28 21:02:59', '2022-11-28 21:02:59', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'URL', 'url', 'publish', 'closed', 'closed', '', 'field_638521e71262c', '', '', '2022-11-28 21:02:59', '2022-11-28 21:02:59', '', 166, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=168', 1, 'acf-field', '', 0),
(195, 4, '2023-02-25 20:25:07', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-25 20:25:07', '0000-00-00 00:00:00', '', 0, 'https://acfheadless.wpengine.local/?p=195', 0, 'post', '', 0),
(196, 4, '2023-02-25 20:28:45', '2023-02-25 20:28:45', 'a:12:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_category";s:8:"operator";s:2:"==";s:5:"value";s:13:"category:food";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;s:15:"show_in_graphql";i:1;s:18:"graphql_field_name";s:13:"foodResources";s:37:"map_graphql_types_from_location_rules";i:0;s:13:"graphql_types";s:0:"";}', 'Food Resources', 'food-resources', 'publish', 'closed', 'closed', '', 'group_63fa6f57401fc', '', '', '2023-02-25 21:27:53', '2023-02-25 21:27:53', '', 0, 'https://acfheadless.wpengine.local/?post_type=acf-field-group&#038;p=196', 0, 'acf-field-group', '', 0),
(197, 4, '2023-02-25 20:28:45', '2023-02-25 20:28:45', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Recipe Link', 'recipe_link', 'publish', 'closed', 'closed', '', 'field_63fa6f583bdb5', '', '', '2023-02-25 21:27:53', '2023-02-25 21:27:53', '', 196, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=197', 1, 'acf-field', '', 0),
(198, 4, '2023-02-25 20:31:18', '2023-02-25 20:31:18', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Recipe Name', 'recipe_name', 'publish', 'closed', 'closed', '', 'field_63fa6f84a5ffb', '', '', '2023-02-25 21:27:53', '2023-02-25 21:27:53', '', 196, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=198', 0, 'acf-field', '', 0),
(199, 4, '2023-02-28 14:50:52', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-28 14:50:52', '0000-00-00 00:00:00', '', 0, 'https://acfheadless.wpengine.local/?post_type=acf-field-group&p=199', 0, 'acf-field-group', '', 0),
(200, 4, '2023-03-01 15:03:40', '2023-03-01 15:03:40', 'a:12:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_category";s:8:"operator";s:2:"==";s:5:"value";s:14:"category:music";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;s:15:"show_in_graphql";i:1;s:18:"graphql_field_name";s:12:"sweetMixtape";s:37:"map_graphql_types_from_location_rules";i:0;s:13:"graphql_types";s:0:"";}', 'Sweet Mixtape', 'sweet-mixtape', 'publish', 'closed', 'closed', '', 'group_63ff6940e91c3', '', '', '2023-03-01 15:59:27', '2023-03-01 15:59:27', '', 0, 'https://acfheadless.wpengine.local/?post_type=acf-field-group&#038;p=200', 0, 'acf-field-group', '', 0),
(201, 4, '2023-03-01 15:03:40', '2023-03-01 15:03:40', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Track Title', 'track_title', 'publish', 'closed', 'closed', '', 'field_63ff6941b60fd', '', '', '2023-03-01 15:04:42', '2023-03-01 15:04:42', '', 200, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=201', 0, 'acf-field', '', 0),
(202, 4, '2023-03-01 15:04:42', '2023-03-01 15:04:42', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Artist', 'artist', 'publish', 'closed', 'closed', '', 'field_63ff6969dcdae', '', '', '2023-03-01 15:04:42', '2023-03-01 15:04:42', '', 200, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=202', 1, 'acf-field', '', 0),
(203, 4, '2023-03-01 15:04:42', '2023-03-01 15:04:42', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Album', 'album', 'publish', 'closed', 'closed', '', 'field_63ff6975dcdaf', '', '', '2023-03-01 15:04:42', '2023-03-01 15:04:42', '', 200, 'https://acfheadless.wpengine.local/?post_type=acf-field&p=203', 2, 'acf-field', '', 0),
(204, 4, '2023-03-01 15:20:23', '2023-03-01 15:20:23', 'a:12:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_category";s:8:"operator";s:2:"==";s:5:"value";s:14:"category:style";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;s:15:"show_in_graphql";i:1;s:18:"graphql_field_name";s:15:"inspiringAttire";s:37:"map_graphql_types_from_location_rules";i:0;s:13:"graphql_types";s:0:"";}', 'Inspiring Attire', 'inspiring-attire', 'trash', 'closed', 'closed', '', 'group_63ff6c9002a6b__trashed', '', '', '2023-03-01 17:31:08', '2023-03-01 17:31:08', '', 0, 'https://acfheadless.wpengine.local/?post_type=acf-field-group&#038;p=204', 0, 'acf-field-group', '', 0),
(205, 4, '2023-03-01 15:20:23', '2023-03-01 15:20:23', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Name', 'name', 'trash', 'closed', 'closed', '', 'field_63ff6c91404d4__trashed', '', '', '2023-03-01 17:31:08', '2023-03-01 17:31:08', '', 204, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=205', 0, 'acf-field', '', 0),
(206, 4, '2023-03-01 15:20:23', '2023-03-01 15:20:23', 'a:17:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:15:"show_in_graphql";i:1;s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Image', 'image', 'trash', 'closed', 'closed', '', 'field_63ff6cc3404d5__trashed', '', '', '2023-03-01 17:31:08', '2023-03-01 17:31:08', '', 204, 'https://acfheadless.wpengine.local/?post_type=acf-field&#038;p=206', 1, 'acf-field', '', 0),
(207, 4, '2023-03-03 17:28:20', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-03-03 17:28:20', '0000-00-00 00:00:00', '', 0, 'http://localhost:3000/?p=207', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(5, 4, 0),
(5, 5, 0),
(6, 2, 0),
(7, 4, 0),
(9, 5, 0),
(10, 5, 0),
(22, 4, 0),
(22, 5, 0),
(23, 4, 0),
(23, 5, 0),
(24, 5, 0),
(26, 5, 0),
(41, 3, 0),
(42, 3, 0),
(43, 3, 0),
(49, 1, 0),
(161, 7, 0),
(161, 8, 0),
(161, 9, 0),
(161, 10, 0),
(161, 11, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 3),
(4, 4, 'category', '', 0, 4),
(5, 5, 'category', '', 0, 7),
(6, 6, 'category', '', 0, 0),
(7, 7, 'gatsby_action_ref_node_dbid', '', 0, 1),
(8, 8, 'gatsby_action_ref_node_type', '', 0, 1),
(9, 9, 'gatsby_action_ref_node_id', '', 0, 1),
(10, 10, 'gatsby_action_type', '', 0, 1),
(11, 11, 'gatsby_action_stream_type', '', 0, 12),
(12, 12, 'gatsby_action_ref_node_dbid', '', 0, 1),
(13, 13, 'gatsby_action_ref_node_type', '', 0, 2),
(14, 14, 'gatsby_action_ref_node_id', '', 0, 1),
(15, 15, 'gatsby_action_type', '', 0, 0),
(16, 16, 'gatsby_action_type', '', 0, 2),
(17, 17, 'gatsby_action_ref_node_dbid', '', 0, 1),
(18, 18, 'gatsby_action_ref_node_type', '', 0, 1),
(19, 19, 'gatsby_action_ref_node_id', '', 0, 1),
(20, 20, 'gatsby_action_type', '', 0, 1),
(21, 21, 'gatsby_action_ref_node_dbid', '', 0, 1),
(22, 22, 'gatsby_action_ref_node_type', '', 0, 1),
(23, 23, 'gatsby_action_ref_node_id', '', 0, 1),
(24, 24, 'gatsby_action_type', '', 0, 8),
(25, 25, 'gatsby_action_ref_node_dbid', '', 0, 1),
(26, 26, 'gatsby_action_ref_node_type', '', 0, 1),
(27, 27, 'gatsby_action_ref_node_id', '', 0, 1),
(28, 28, 'gatsby_action_ref_node_dbid', '', 0, 1),
(29, 29, 'gatsby_action_ref_node_type', '', 0, 1),
(30, 30, 'gatsby_action_ref_node_id', '', 0, 1),
(31, 31, 'gatsby_action_ref_node_dbid', '', 0, 1),
(32, 32, 'gatsby_action_ref_node_id', '', 0, 1),
(33, 33, 'gatsby_action_ref_node_dbid', '', 0, 1),
(34, 34, 'gatsby_action_ref_node_id', '', 0, 1),
(35, 35, 'gatsby_action_ref_node_dbid', '', 0, 1),
(36, 36, 'gatsby_action_ref_node_type', '', 0, 7),
(37, 37, 'gatsby_action_ref_node_id', '', 0, 1),
(38, 38, 'gatsby_action_ref_node_dbid', '', 0, 1),
(39, 39, 'gatsby_action_ref_node_id', '', 0, 1),
(40, 40, 'gatsby_action_ref_node_dbid', '', 0, 1),
(41, 41, 'gatsby_action_ref_node_id', '', 0, 1),
(42, 42, 'gatsby_action_ref_node_dbid', '', 0, 1),
(43, 43, 'gatsby_action_ref_node_id', '', 0, 1),
(44, 44, 'gatsby_action_ref_node_dbid', '', 0, 1),
(45, 45, 'gatsby_action_ref_node_id', '', 0, 1),
(46, 46, 'gatsby_action_ref_node_dbid', '', 0, 1),
(47, 47, 'gatsby_action_ref_node_id', '', 0, 1),
(48, 48, 'gatsby_action_ref_node_dbid', '', 0, 1),
(49, 49, 'gatsby_action_ref_node_id', '', 0, 1),
(50, 50, 'gatsby_action_ref_node_dbid', '', 0, 1),
(51, 51, 'gatsby_action_ref_node_id', '', 0, 1),
(52, 52, 'gatsby_action_ref_node_dbid', '', 0, 1),
(53, 53, 'gatsby_action_ref_node_id', '', 0, 1),
(54, 54, 'gatsby_action_ref_node_dbid', '', 0, 1),
(55, 55, 'gatsby_action_ref_node_id', '', 0, 1),
(56, 56, 'gatsby_action_ref_node_dbid', '', 0, 1),
(57, 57, 'gatsby_action_ref_node_id', '', 0, 1),
(58, 58, 'gatsby_action_ref_node_dbid', '', 0, 1),
(59, 59, 'gatsby_action_ref_node_id', '', 0, 1),
(60, 60, 'post_tag', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'genesis-block-theme', 'genesis-block-theme', 0),
(3, 'MainMenu', 'mainmenu', 0),
(4, 'Music', 'music', 0),
(5, 'Food', 'food', 0),
(6, 'Style', 'style', 0),
(7, 'update_non_node_root_field', 'update_non_node_root_field', 0),
(8, 'update_non_node_root_field', 'update_non_node_root_field', 0),
(9, 'update_non_node_root_field', 'update_non_node_root_field', 0),
(10, 'NON_NODE_ROOT_FIELDS', 'non_node_root_fields', 0),
(11, 'CONTENT', 'content', 0),
(12, '47', '47', 0),
(13, 'mediaItem', 'mediaitem', 0),
(14, 'cG9zdDo0Nw==', 'cg9zddo0nw', 0),
(15, 'CREATE', 'create', 0),
(16, 'DELETE', 'delete', 0),
(17, 'none', 'none', 0),
(18, 'none', 'none', 0),
(19, 'none', 'none', 0),
(20, 'DIFF_SCHEMAS', 'diff_schemas', 0),
(21, '1', '1', 0),
(22, 'user', 'user', 0),
(23, 'dXNlcjox', 'dxnlcjox', 0),
(24, 'UPDATE', 'update', 0),
(25, '153', '153', 0),
(26, 'page', 'page', 0),
(27, 'cG9zdDoxNTM=', 'cg9zddoxntm', 0),
(28, 'post', 'post', 0),
(29, 'contentType', 'contenttype', 0),
(30, 'cG9zdF90eXBlOnBvc3Q=', 'cg9zdf90exblonbvc3q', 0),
(31, '38', '38', 0),
(32, 'cG9zdDozOA==', 'cg9zddozoa', 0),
(33, '159', '159', 0),
(34, 'cG9zdDoxNTk=', 'cg9zddoxntk', 0),
(35, '26', '26', 0),
(36, 'post', 'post', 0),
(37, 'cG9zdDoyNg==', 'cg9zddoyng', 0),
(38, '172', '172', 0),
(39, 'cG9zdDoxNzI=', 'cg9zddoxnzi', 0),
(40, '175', '175', 0),
(41, 'cG9zdDoxNzU=', 'cg9zddoxnzu', 0),
(42, '181', '181', 0),
(43, 'cG9zdDoxODE=', 'cg9zddoxode', 0),
(44, '24', '24', 0),
(45, 'cG9zdDoyNA==', 'cg9zddoyna', 0),
(46, '23', '23', 0),
(47, 'cG9zdDoyMw==', 'cg9zddoymw', 0),
(48, '22', '22', 0),
(49, 'cG9zdDoyMg==', 'cg9zddoymg', 0),
(50, '10', '10', 0),
(51, 'cG9zdDoxMA==', 'cg9zddoxma', 0),
(52, '9', '9', 0),
(53, 'cG9zdDo5', 'cg9zddo5', 0),
(54, '7', '7', 0),
(55, 'cG9zdDo3', 'cg9zddo3', 0),
(56, '5', '5', 0),
(57, 'cG9zdDo1', 'cg9zddo1', 0),
(58, '193', '193', 0),
(59, 'cG9zdDoxOTM=', 'cg9zddoxotm', 0),
(60, 'how-to', 'how-to', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(72, 4, 'nickname', 'admin'),
(73, 4, 'first_name', ''),
(74, 4, 'last_name', ''),
(75, 4, 'description', ''),
(76, 4, 'rich_editing', 'true'),
(77, 4, 'syntax_highlighting', 'true'),
(78, 4, 'comment_shortcuts', 'false'),
(79, 4, 'admin_color', 'fresh'),
(80, 4, 'use_ssl', '0'),
(81, 4, 'show_admin_bar_front', 'true'),
(82, 4, 'locale', ''),
(83, 4, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(84, 4, 'wp_user_level', '10'),
(85, 4, 'dismissed_wp_pointers', ''),
(86, 4, 'session_tokens', 'a:1:{s:64:"2da22fa06c5bd2a687c633712af8477c02662980d5a188f437d8a122ccc68940";a:4:{s:10:"expiration";i:1678037298;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1677864498;}}'),
(87, 4, 'wp_dashboard_quick_press_last_post_id', '207'),
(88, 4, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(4, 'admin', '$P$BfpFMWH9NlCjAFkCNUYSGaiAJdzGJl1', 'admin', 'admin@mailinator.com', '', '2023-03-01 18:18:03', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

